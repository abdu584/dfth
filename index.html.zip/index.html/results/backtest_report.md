# Backtest Report

## Configuration
- Strategy: EMA Crossover
- Symbols: BTC/USDT
- Timeframe: 1d
- Start Date: 2024-01-01 00:00:00
- End Date: 2024-12-31 00:00:00
- Initial Capital: $10000.00
- Market Type: spot
- Leverage: 1x
- Commission Rate: 0.10%

## Performance Metrics
- Final Capital: $9942.18
- Total PnL: $-57.82 (-0.58%)
- Win Rate: 11.11% (1 wins, 8 losses)
- Max Drawdown: 2.51%
- Sharpe Ratio: -0.02
- Sortino Ratio: -0.01
- Profit Factor: 0.24

## Trade Summary
- Total Trades: 9
- Average PnL per Trade: $-6.22
- Average PnL Percentage per Trade: -3.12%
- Average Trade Duration: 21760.00 minutes

## Top 5 Trades
1. BTC/USDT: $18.18 (9.13%) - Entry: 2024-06-28 00:00:00, Exit: 2024-08-20 00:00:00
2. BTC/USDT: $-4.37 (-2.19%) - Entry: 2024-06-02 00:00:00, Exit: 2024-06-11 00:00:00
3. BTC/USDT: $-6.28 (-3.14%) - Entry: 2024-01-09 00:00:00, Exit: 2024-01-10 00:00:00
4. BTC/USDT: $-7.47 (-3.74%) - Entry: 2024-09-09 00:00:00, Exit: 2024-09-28 00:00:00
5. BTC/USDT: $-8.15 (-4.09%) - Entry: 2024-10-03 00:00:00, Exit: 2024-10-11 00:00:00

## Bottom 5 Trades
1. BTC/USDT: $-17.70 (-8.89%) - Entry: 2024-11-25 00:00:00, Exit: 2024-11-29 00:00:00
2. BTC/USDT: $-11.69 (-5.86%) - Entry: 2024-06-12 00:00:00, Exit: 2024-06-17 00:00:00
3. BTC/USDT: $-9.47 (-4.74%) - Entry: 2024-02-22 00:00:00, Exit: 2024-03-09 00:00:00
4. BTC/USDT: $-9.08 (-4.54%) - Entry: 2024-01-22 00:00:00, Exit: 2024-02-12 00:00:00
5. BTC/USDT: $-8.15 (-4.09%) - Entry: 2024-10-03 00:00:00, Exit: 2024-10-11 00:00:00