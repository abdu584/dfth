"""
Data structures for the Crypto Trading Bot.

This module defines the core data structures used throughout the trading bot:
- Exchange API connections
- OHLCV (Open, High, Low, Close, Volume) data
- Trading signals and indicators
- Orders and positions
- Backtest results
- Predictions
- Configuration settings
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional, Union, Tuple, Any
import datetime
import pandas as pd
import numpy as np


class TradeSide(Enum):
    """Enum representing the side of a trade."""
    BUY = "buy"
    SELL = "sell"


class OrderType(Enum):
    """Enum representing the type of order."""
    MARKET = "market"
    LIMIT = "limit"
    STOP_LOSS = "stop_loss"
    TAKE_PROFIT = "take_profit"


class MarketType(Enum):
    """Enum representing the market type."""
    SPOT = "spot"
    FUTURES = "futures"


class TimeFrame(Enum):
    """Enum representing the timeframe for OHLCV data."""
    MINUTE_1 = "1m"
    MINUTE_5 = "5m"
    MINUTE_15 = "15m"
    MINUTE_30 = "30m"
    HOUR_1 = "1h"
    HOUR_4 = "4h"
    DAY_1 = "1d"
    WEEK_1 = "1w"


class PredictionDirection(Enum):
    """Enum representing the direction of a prediction."""
    BULLISH = "bullish"
    BEARISH = "bearish"
    NEUTRAL = "neutral"


@dataclass
class ExchangeCredentials:
    """Data structure for exchange API credentials."""
    exchange_id: str
    api_key: str
    api_secret: str
    passphrase: Optional[str] = None  # Some exchanges like OKX require a passphrase
    testnet: bool = False


@dataclass
class OHLCV:
    """Data structure for OHLCV data."""
    symbol: str
    timeframe: TimeFrame
    timestamp: List[int]
    open: List[float]
    high: List[float]
    low: List[float]
    close: List[float]
    volume: List[float]
    
    def to_dataframe(self) -> pd.DataFrame:
        """Convert OHLCV data to pandas DataFrame."""
        df = pd.DataFrame({
            'timestamp': self.timestamp,
            'open': self.open,
            'high': self.high,
            'low': self.low,
            'close': self.close,
            'volume': self.volume
        })
        df['datetime'] = pd.to_datetime(df['timestamp'], unit='ms')
        df.set_index('datetime', inplace=True)
        return df


@dataclass
class Order:
    """Data structure for an order."""
    symbol: str
    side: TradeSide
    order_type: OrderType
    quantity: float
    price: Optional[float] = None  # Required for limit orders
    stop_price: Optional[float] = None  # Required for stop orders
    leverage: int = 1  # For futures trading
    order_id: Optional[str] = None  # Filled when order is placed
    status: str = "new"
    timestamp: Optional[int] = None
    filled_quantity: float = 0.0
    average_fill_price: Optional[float] = None
    commission: float = 0.0
    commission_asset: Optional[str] = None


@dataclass
class Position:
    """Data structure for a position."""
    symbol: str
    side: TradeSide
    quantity: float
    entry_price: float
    leverage: int = 1
    liquidation_price: Optional[float] = None
    unrealized_pnl: float = 0.0
    realized_pnl: float = 0.0
    timestamp: Optional[int] = None


@dataclass
class Trade:
    """Data structure for a completed trade (entry and exit)."""
    symbol: str
    entry_order: Order
    exit_order: Optional[Order] = None
    pnl: float = 0.0
    pnl_percentage: float = 0.0
    duration: Optional[int] = None  # Duration in milliseconds
    strategy_name: str = "default"


@dataclass
class BacktestConfig:
    """Data structure for backtest configuration."""
    start_date: datetime.datetime
    end_date: datetime.datetime
    initial_capital: float
    symbols: List[str]
    timeframe: TimeFrame
    strategy_name: str
    market_type: MarketType = MarketType.SPOT
    leverage: int = 1
    commission_rate: float = 0.001  # 0.1% by default
    slippage: float = 0.0005  # 0.05% by default


@dataclass
class BacktestResult:
    """Data structure for backtest results."""
    config: BacktestConfig
    trades: List[Trade] = field(default_factory=list)
    equity_curve: List[float] = field(default_factory=list)
    timestamps: List[int] = field(default_factory=list)
    
    # Performance metrics
    total_pnl: float = 0.0
    total_pnl_percentage: float = 0.0
    win_count: int = 0
    loss_count: int = 0
    win_rate: float = 0.0
    max_drawdown: float = 0.0
    max_drawdown_percentage: float = 0.0
    sharpe_ratio: float = 0.0
    sortino_ratio: float = 0.0
    profit_factor: float = 0.0
    
    def to_dataframe(self) -> pd.DataFrame:
        """Convert equity curve to pandas DataFrame."""
        df = pd.DataFrame({
            'timestamp': self.timestamps,
            'equity': self.equity_curve
        })
        df['datetime'] = pd.to_datetime(df['timestamp'], unit='ms')
        df.set_index('datetime', inplace=True)
        return df


@dataclass
class Prediction:
    """Data structure for a prediction."""
    symbol: str
    direction: PredictionDirection
    confidence: float  # 0.0 to 1.0
    timestamp: int
    features: Dict[str, float] = field(default_factory=dict)
    model_name: str = "default"


@dataclass
class TradingBotConfig:
    """Data structure for trading bot configuration."""
    exchange_credentials: List[ExchangeCredentials]
    symbols: List[str]
    timeframe: TimeFrame
    strategy_name: str
    market_type: MarketType
    initial_capital: float
    leverage: int = 1
    risk_per_trade: float = 0.02  # 2% of capital per trade
    max_open_positions: int = 5
    stop_loss_percentage: Optional[float] = None
    take_profit_percentage: Optional[float] = None
    trailing_stop_percentage: Optional[float] = None
    
    # Prediction engine settings
    prediction_window: int = 7  # Days for prediction
    prediction_threshold: float = 0.7  # Confidence threshold
    
    # Logging settings
    log_level: str = "INFO"
    log_file: Optional[str] = None
    
    # Mode settings
    backtest_mode: bool = False
    paper_trading: bool = True  # If False, real trading
