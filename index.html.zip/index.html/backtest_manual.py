"""
Backtesting implementation for Crypto Trading Bot (with manual indicator calculations).

This module implements the backtesting engine functionality:
- Loading historical data
- Running strategy on historical data
- Calculating performance metrics
- Visualizing results
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from typing import Dict, List, Optional, Union, Tuple, Any
import datetime
import logging
import os
from pathlib import Path
import json

from data_structures import (
    OHLCV, Order, Trade, BacktestConfig, BacktestResult,
    TradeSide, OrderType, MarketType, TimeFrame
)
from strategy_manual import Strategy, EMACrossoverStrategy


class BacktestingEngine:
    """Engine for backtesting trading strategies on historical data."""
    
    def __init__(self, config: BacktestConfig):
        """
        Initialize the backtesting engine with configuration.
        
        Args:
            config: BacktestConfig object containing backtest parameters
        """
        self.config = config
        self.data = {}  # Dict to store OHLCV data for each symbol
        self.current_capital = config.initial_capital
        self.trades = []
        self.equity_curve = []
        self.timestamps = []
        self.open_positions = {}
        self.logger = logging.getLogger(__name__)
    
    def load_data(self, data_dict: Dict[str, OHLCV]) -> None:
        """
        Load OHLCV data for backtesting.
        
        Args:
            data_dict: Dictionary mapping symbols to OHLCV objects
        """
        self.data = data_dict
        self.logger.info(f"Loaded data for {len(data_dict)} symbols")
    
    def load_csv_data(self, csv_path: str, symbol: str) -> None:
        """
        Load OHLCV data from CSV file.
        
        Args:
            csv_path: Path to CSV file
            symbol: Symbol for the data
        """
        df = pd.read_csv(csv_path)
        
        # Convert timestamp to datetime if needed
        if 'timestamp' in df.columns:
            if isinstance(df['timestamp'].iloc[0], str):
                df['timestamp'] = pd.to_datetime(df['timestamp']).astype(np.int64) // 10**6
        elif 'datetime' in df.columns:
            df['timestamp'] = pd.to_datetime(df['datetime']).astype(np.int64) // 10**6
        
        # Ensure required columns exist
        required_columns = ['timestamp', 'open', 'high', 'low', 'close', 'volume']
        for col in required_columns:
            if col not in df.columns:
                raise ValueError(f"Required column '{col}' not found in CSV file")
        
        # Create OHLCV object
        ohlcv = OHLCV(
            symbol=symbol,
            timeframe=self.config.timeframe,
            timestamp=df['timestamp'].tolist(),
            open=df['open'].tolist(),
            high=df['high'].tolist(),
            low=df['low'].tolist(),
            close=df['close'].tolist(),
            volume=df['volume'].tolist()
        )
        
        self.data[symbol] = ohlcv
        self.logger.info(f"Loaded data for {symbol} from CSV file")
    
    def generate_sample_data(self, symbol: str, days: int = 365) -> None:
        """
        Generate sample OHLCV data for testing.
        
        Args:
            symbol: Symbol for the data
            days: Number of days of data to generate
        """
        # Ensure the generated data covers the backtest date range
        if self.config.start_date and self.config.end_date:
            # Use the backtest date range with some padding
            end_date = self.config.end_date + datetime.timedelta(days=10)
            start_date = self.config.start_date - datetime.timedelta(days=10)
        else:
            # Default to recent data if no date range specified
            end_date = datetime.datetime.now()
            start_date = end_date - datetime.timedelta(days=days)
        
        # Generate timestamps
        timestamps = []
        current_date = start_date
        while current_date <= end_date:
            timestamps.append(int(current_date.timestamp() * 1000))
            current_date += datetime.timedelta(days=1)
        
        # Generate price data with random walk
        n = len(timestamps)
        close = [10000]  # Start price
        for i in range(1, n):
            # Random daily return between -3% and +3%
            daily_return = np.random.normal(0.0005, 0.02)
            close.append(close[-1] * (1 + daily_return))
        
        # Generate OHLC based on close prices
        open_prices = [close[0]] + close[:-1]
        high = [c * (1 + abs(np.random.normal(0, 0.01))) for c in close]
        low = [c * (1 - abs(np.random.normal(0, 0.01))) for c in close]
        
        # Generate volume
        volume = [abs(np.random.normal(1000, 500)) * c for c in close]
        
        # Create OHLCV object
        ohlcv = OHLCV(
            symbol=symbol,
            timeframe=self.config.timeframe,
            timestamp=timestamps,
            open=open_prices,
            high=high,
            low=low,
            close=close,
            volume=volume
        )
        
        self.data[symbol] = ohlcv
        self.logger.info(f"Generated sample data for {symbol} from {start_date} to {end_date}")
    
    def run_backtest(self, strategy: Strategy) -> BacktestResult:
        """
        Run backtest using the provided strategy.
        
        Args:
            strategy: Strategy object that generates trading signals
                
        Returns:
            BacktestResult object containing performance metrics and trades
        """
        self.logger.info(f"Starting backtest with {strategy.name} strategy")
        
        # Reset backtest state
        self.current_capital = self.config.initial_capital
        self.trades = []
        self.equity_curve = [self.current_capital]
        self.timestamps = []
        self.open_positions = {}
        
        # Run backtest for each symbol
        for symbol in self.config.symbols:
            if symbol not in self.data:
                self.logger.warning(f"No data for symbol {symbol}, skipping")
                continue
            
            # Convert OHLCV to DataFrame
            ohlcv_df = self.data[symbol].to_dataframe()
            
            # Filter data based on backtest date range
            start_timestamp = int(self.config.start_date.timestamp() * 1000)
            end_timestamp = int(self.config.end_date.timestamp() * 1000)
            
            # Debug info
            self.logger.info(f"Filtering data for {symbol} from {self.config.start_date} to {self.config.end_date}")
            self.logger.info(f"Data range: {ohlcv_df.index.min()} to {ohlcv_df.index.max()}")
            
            # Convert index to millisecond timestamps for filtering
            ohlcv_df['ms_timestamp'] = ohlcv_df.index.astype(np.int64) // 10**6
            filtered_df = ohlcv_df[(ohlcv_df['ms_timestamp'] >= start_timestamp) & 
                                  (ohlcv_df['ms_timestamp'] <= end_timestamp)]
            
            # Remove the temporary column
            if 'ms_timestamp' in filtered_df.columns:
                filtered_df = filtered_df.drop('ms_timestamp', axis=1)
            
            if len(filtered_df) == 0:
                self.logger.warning(f"No data for symbol {symbol} in date range, skipping")
                continue
            
            self.logger.info(f"Found {len(filtered_df)} data points for {symbol} in date range")
            
            # Generate signals
            signals_df = strategy.generate_signals(filtered_df)
            
            # Simulate trading
            self._simulate_trading(symbol, signals_df)
        
        # Calculate performance metrics
        metrics = self._calculate_metrics()
        
        # Create backtest result
        result = BacktestResult(
            config=self.config,
            trades=self.trades,
            equity_curve=self.equity_curve,
            timestamps=self.timestamps,
            total_pnl=metrics['total_pnl'],
            total_pnl_percentage=metrics['total_pnl_percentage'],
            win_count=metrics['win_count'],
            loss_count=metrics['loss_count'],
            win_rate=metrics['win_rate'],
            max_drawdown=metrics['max_drawdown'],
            max_drawdown_percentage=metrics['max_drawdown_percentage'],
            sharpe_ratio=metrics['sharpe_ratio'],
            sortino_ratio=metrics['sortino_ratio'],
            profit_factor=metrics['profit_factor']
        )
        
        self.logger.info(f"Backtest completed with {len(self.trades)} trades")
        return result
    
    def _simulate_trading(self, symbol: str, signals_df: pd.DataFrame) -> None:
        """
        Simulate trading based on signals.
        
        Args:
            symbol: Symbol to trade
            signals_df: DataFrame with signals
        """
        # Initialize timestamps if empty
        if not self.timestamps:
            # Use the first timestamp as the starting point
            first_timestamp = int(signals_df.index[0].timestamp() * 1000)
            self.timestamps.append(first_timestamp)
            
        for i, row in signals_df.iterrows():
            timestamp = int(i.timestamp() * 1000)
            
            # Only add timestamp if it's new
            if not self.timestamps or timestamp > self.timestamps[-1]:
                self.timestamps.append(timestamp)
            
            # Check for signals
            if row['signal'] == 1:  # Buy signal
                if symbol not in self.open_positions:
                    # Calculate position size
                    position_size = self._calculate_position_size(symbol, row['close'])
                    
                    # Create order
                    order = Order(
                        symbol=symbol,
                        side=TradeSide.BUY,
                        order_type=OrderType.MARKET,
                        quantity=position_size,
                        price=row['close'],
                        leverage=self.config.leverage,
                        timestamp=timestamp,
                        status="filled",
                        filled_quantity=position_size,
                        average_fill_price=row['close'],
                        commission=position_size * row['close'] * self.config.commission_rate
                    )
                    
                    # Execute order
                    self._execute_order(order)
            
            elif row['signal'] == -1:  # Sell signal
                if symbol in self.open_positions:
                    # Create order
                    position = self.open_positions[symbol]
                    order = Order(
                        symbol=symbol,
                        side=TradeSide.SELL,
                        order_type=OrderType.MARKET,
                        quantity=position['quantity'],
                        price=row['close'],
                        leverage=self.config.leverage,
                        timestamp=timestamp,
                        status="filled",
                        filled_quantity=position['quantity'],
                        average_fill_price=row['close'],
                        commission=position['quantity'] * row['close'] * self.config.commission_rate
                    )
                    
                    # Execute order
                    self._execute_order(order)
            
            # Update equity curve
            self._update_equity(timestamp, signals_df.loc[:i])
    
    def _calculate_position_size(self, symbol: str, price: float) -> float:
        """
        Calculate position size based on risk parameters.
        
        Args:
            symbol: Symbol to trade
            price: Current price
            
        Returns:
            Position size in base currency
        """
        # Use a fixed percentage of capital for each trade
        risk_amount = self.current_capital * 0.02  # 2% risk per trade
        
        # Calculate position size
        position_size = risk_amount / price
        
        return position_size
    
    def _execute_order(self, order: Order) -> None:
        """
        Execute order in backtest.
        
        Args:
            order: Order to execute
        """
        if order.side == TradeSide.BUY:
            # Calculate cost
            cost = order.filled_quantity * order.average_fill_price * (1 + self.config.commission_rate)
            
            # Update capital
            self.current_capital -= cost
            
            # Add to open positions
            self.open_positions[order.symbol] = {
                'quantity': order.filled_quantity,
                'entry_price': order.average_fill_price,
                'entry_time': order.timestamp,
                'entry_order': order
            }
            
            self.logger.debug(f"Opened position: {order.symbol} @ {order.average_fill_price}")
        
        elif order.side == TradeSide.SELL:
            # Get position
            position = self.open_positions[order.symbol]
            
            # Calculate revenue
            revenue = order.filled_quantity * order.average_fill_price * (1 - self.config.commission_rate)
            
            # Calculate PnL
            entry_cost = position['quantity'] * position['entry_price']
            pnl = revenue - entry_cost
            pnl_percentage = (revenue / entry_cost - 1) * 100
            
            # Update capital
            self.current_capital += revenue
            
            # Create trade record
            trade = Trade(
                symbol=order.symbol,
                entry_order=position['entry_order'],
                exit_order=order,
                pnl=pnl,
                pnl_percentage=pnl_percentage,
                duration=order.timestamp - position['entry_time'],
                strategy_name=self.config.strategy_name
            )
            
            # Add to trades list
            self.trades.append(trade)
            
            # Remove from open positions
            del self.open_positions[order.symbol]
            
            self.logger.debug(f"Closed position: {order.symbol} @ {order.average_fill_price}, PnL: {pnl:.2f} ({pnl_percentage:.2f}%)")
    
    def _update_equity(self, timestamp: int, current_data: pd.DataFrame) -> None:
        """
        Update equity curve at current timestamp.
        
        Args:
            timestamp: Current timestamp
            current_data: Current price data
        """
        # Calculate unrealized PnL
        unrealized_pnl = 0
        for symbol, position in self.open_positions.items():
            current_price = current_data.loc[current_data.index[-1], 'close']
            position_value = position['quantity'] * current_price
            cost_basis = position['quantity'] * position['entry_price']
            unrealized_pnl += position_value - cost_basis
        
        # Update equity curve
        total_equity = self.current_capital + unrealized_pnl
        self.equity_curve.append(total_equity)
    
    def _calculate_metrics(self) -> Dict[str, float]:
        """
        Calculate performance metrics from backtest results.
        
        Returns:
            Dictionary of performance metrics
        """
        # Basic metrics
        initial_capital = self.config.initial_capital
        final_capital = self.equity_curve[-1] if self.equity_curve else initial_capital
        total_pnl = final_capital - initial_capital
        total_pnl_percentage = (total_pnl / initial_capital) * 100
        
        # Win/loss metrics
        win_trades = [t for t in self.trades if t.pnl > 0]
        loss_trades = [t for t in self.trades if t.pnl <= 0]
        win_count = len(win_trades)
        loss_count = len(loss_trades)
        win_rate = win_count / len(self.trades) if self.trades else 0
        
        # Calculate drawdown
        equity_array = np.array(self.equity_curve)
        peak = np.maximum.accumulate(equity_array)
        drawdown = (peak - equity_array) / peak
        max_drawdown = np.max(drawdown) if len(drawdown) > 0 else 0
        max_drawdown_percentage = max_drawdown * 100
        
        # Calculate Sharpe ratio
        if len(self.equity_curve) > 1:
            returns = np.diff(self.equity_curve) / self.equity_curve[:-1]
            sharpe_ratio = np.mean(returns) / np.std(returns) * np.sqrt(252) if np.std(returns) > 0 else 0
            
            # Calculate Sortino ratio (using only negative returns)
            negative_returns = returns[returns < 0]
            sortino_ratio = np.mean(returns) / np.std(negative_returns) * np.sqrt(252) if len(negative_returns) > 0 and np.std(negative_returns) > 0 else 0
        else:
            sharpe_ratio = 0
            sortino_ratio = 0
        
        # Calculate profit factor
        total_profit = sum(t.pnl for t in win_trades)
        total_loss = abs(sum(t.pnl for t in loss_trades))
        profit_factor = total_profit / total_loss if total_loss > 0 else 0
        
        return {
            'total_pnl': total_pnl,
            'total_pnl_percentage': total_pnl_percentage,
            'win_count': win_count,
            'loss_count': loss_count,
            'win_rate': win_rate,
            'max_drawdown': max_drawdown,
            'max_drawdown_percentage': max_drawdown_percentage,
            'sharpe_ratio': sharpe_ratio,
            'sortino_ratio': sortino_ratio,
            'profit_factor': profit_factor
        }
    
    def plot_equity_curve(self, save_path: Optional[str] = None) -> None:
        """
        Plot equity curve and drawdown.
        
        Args:
            save_path: Optional path to save the plot
        """
        if not self.equity_curve or not self.timestamps:
            self.logger.warning("No equity curve data to plot")
            
            # Create a simple placeholder plot
            plt.figure(figsize=(12, 8))
            plt.title('No Equity Curve Data Available')
            plt.xlabel('Date')
            plt.ylabel('Equity')
            plt.grid(True)
            
            if save_path:
                # Ensure directory exists
                os.makedirs(os.path.dirname(save_path), exist_ok=True)
                plt.savefig(save_path)
                self.logger.info(f"Empty equity curve plot saved to {save_path}")
            return
        
        # Create figure with two subplots
        fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(12, 8), gridspec_kw={'height_ratios': [3, 1]})
        
        # Convert timestamps to datetime
        dates = [datetime.datetime.fromtimestamp(ts/1000) for ts in self.timestamps]
        
        # Ensure dates and equity curve have the same length
        min_len = min(len(dates), len(self.equity_curve))
        dates = dates[:min_len]
        equity_curve = self.equity_curve[:min_len]
        
        # Plot equity curve
        ax1.plot(dates, equity_curve, label='Equity Curve')
        ax1.set_title('Backtest Results')
        ax1.set_ylabel('Equity')
        ax1.grid(True)
        ax1.legend()
        
        # Calculate drawdown
        equity_array = np.array(equity_curve)
        peak = np.maximum.accumulate(equity_array)
        drawdown = (peak - equity_array) / peak * 100  # Convert to percentage
        
        # Plot drawdown
        ax2.fill_between(dates, 0, drawdown, color='red', alpha=0.3)
        ax2.set_title('Drawdown')
        ax2.set_ylabel('Drawdown %')
        ax2.set_xlabel('Date')
        ax2.grid(True)
        
        # Format x-axis
        plt.gcf().autofmt_xdate()
        
        # Adjust layout
        plt.tight_layout()
        
        # Save or show
        if save_path:
            # Ensure directory exists
            os.makedirs(os.path.dirname(save_path), exist_ok=True)
            plt.savefig(save_path)
            self.logger.info(f"Equity curve plot saved to {save_path}")
        else:
            plt.show()
    
    def plot_trades(self, symbol: str, save_path: Optional[str] = None) -> None:
        """
        Plot trades on price chart for a specific symbol.
        
        Args:
            symbol: Symbol to plot trades for
            save_path: Optional path to save the plot
        """
        if symbol not in self.data:
            self.logger.warning(f"No data for symbol {symbol}")
            return
        
        # Get OHLCV data
        ohlcv_df = self.data[symbol].to_dataframe()
        
        # Filter trades for this symbol
        symbol_trades = [t for t in self.trades if t.symbol == symbol]
        
        # Create figure
        fig, ax = plt.subplots(figsize=(12, 6))
        
        # Plot price
        ax.plot(ohlcv_df.index, ohlcv_df['close'], label='Close Price')
        
        if symbol_trades:
            # Plot buy points
            buy_times = [datetime.datetime.fromtimestamp(t.entry_order.timestamp/1000) for t in symbol_trades]
            buy_prices = [t.entry_order.average_fill_price for t in symbol_trades]
            ax.scatter(buy_times, buy_prices, marker='^', color='green', s=100, label='Buy')
            
            # Plot sell points
            sell_times = [datetime.datetime.fromtimestamp(t.exit_order.timestamp/1000) for t in symbol_trades if t.exit_order]
            sell_prices = [t.exit_order.average_fill_price for t in symbol_trades if t.exit_order]
            ax.scatter(sell_times, sell_prices, marker='v', color='red', s=100, label='Sell')
        else:
            self.logger.warning(f"No trades for symbol {symbol}")
        
        # Set labels and title
        ax.set_title(f'Price Chart for {symbol}')
        ax.set_ylabel('Price')
        ax.set_xlabel('Date')
        ax.grid(True)
        ax.legend()
        
        # Format x-axis
        plt.gcf().autofmt_xdate()
        
        # Adjust layout
        plt.tight_layout()
        
        # Save or show
        if save_path:
            # Ensure directory exists
            os.makedirs(os.path.dirname(save_path), exist_ok=True)
            plt.savefig(save_path)
            self.logger.info(f"Trades plot saved to {save_path}")
        else:
            plt.show()
    
    def generate_report(self, save_path: Optional[str] = None) -> str:
        """
        Generate detailed backtest report.
        
        Args:
            save_path: Optional path to save the report
            
        Returns:
            Report as string
        """
        # Calculate metrics
        metrics = self._calculate_metrics()
        
        # Create report
        report = []
        report.append("# Backtest Report")
        report.append("")
        report.append("## Configuration")
        report.append(f"- Strategy: {self.config.strategy_name}")
        report.append(f"- Symbols: {', '.join(self.config.symbols)}")
        report.append(f"- Timeframe: {self.config.timeframe.value}")
        report.append(f"- Start Date: {self.config.start_date}")
        report.append(f"- End Date: {self.config.end_date}")
        report.append(f"- Initial Capital: ${self.config.initial_capital:.2f}")
        report.append(f"- Market Type: {self.config.market_type.value}")
        report.append(f"- Leverage: {self.config.leverage}x")
        report.append(f"- Commission Rate: {self.config.commission_rate * 100:.2f}%")
        report.append("")
        
        report.append("## Performance Metrics")
        report.append(f"- Final Capital: ${self.equity_curve[-1] if self.equity_curve else self.config.initial_capital:.2f}")
        report.append(f"- Total PnL: ${metrics['total_pnl']:.2f} ({metrics['total_pnl_percentage']:.2f}%)")
        
        if self.trades:
            report.append(f"- Win Rate: {metrics['win_rate'] * 100:.2f}% ({metrics['win_count']} wins, {metrics['loss_count']} losses)")
            report.append(f"- Max Drawdown: {metrics['max_drawdown_percentage']:.2f}%")
            report.append(f"- Sharpe Ratio: {metrics['sharpe_ratio']:.2f}")
            report.append(f"- Sortino Ratio: {metrics['sortino_ratio']:.2f}")
            report.append(f"- Profit Factor: {metrics['profit_factor']:.2f}")
            report.append("")
            
            report.append("## Trade Summary")
            report.append(f"- Total Trades: {len(self.trades)}")
            report.append(f"- Average PnL per Trade: ${sum(t.pnl for t in self.trades) / len(self.trades):.2f}")
            report.append(f"- Average PnL Percentage per Trade: {sum(t.pnl_percentage for t in self.trades) / len(self.trades):.2f}%")
            report.append(f"- Average Trade Duration: {sum(t.duration for t in self.trades) / len(self.trades) / 1000 / 60:.2f} minutes")
            report.append("")
            
            # Only include top/bottom trades if there are trades
            if len(self.trades) > 0:
                report.append("## Top 5 Trades")
                top_trades = sorted(self.trades, key=lambda t: t.pnl, reverse=True)[:min(5, len(self.trades))]
                for i, trade in enumerate(top_trades, 1):
                    entry_time = datetime.datetime.fromtimestamp(trade.entry_order.timestamp/1000)
                    exit_time = datetime.datetime.fromtimestamp(trade.exit_order.timestamp/1000) if trade.exit_order else "N/A"
                    report.append(f"{i}. {trade.symbol}: ${trade.pnl:.2f} ({trade.pnl_percentage:.2f}%) - Entry: {entry_time}, Exit: {exit_time}")
                report.append("")
                
                report.append("## Bottom 5 Trades")
                bottom_trades = sorted(self.trades, key=lambda t: t.pnl)[:min(5, len(self.trades))]
                for i, trade in enumerate(bottom_trades, 1):
                    entry_time = datetime.datetime.fromtimestamp(trade.entry_order.timestamp/1000)
                    exit_time = datetime.datetime.fromtimestamp(trade.exit_order.timestamp/1000) if trade.exit_order else "N/A"
                    report.append(f"{i}. {trade.symbol}: ${trade.pnl:.2f} ({trade.pnl_percentage:.2f}%) - Entry: {entry_time}, Exit: {exit_time}")
        else:
            report.append("\n## No Trades Executed")
            report.append("No trades were executed during the backtest period. This could be due to:")
            report.append("- No signals generated by the strategy")
            report.append("- Insufficient data in the specified date range")
            report.append("- Strategy parameters not optimized for the market conditions")
        
        # Join report
        report_str = "\n".join(report)
        
        # Save report
        if save_path:
            # Ensure directory exists
            os.makedirs(os.path.dirname(save_path), exist_ok=True)
            with open(save_path, 'w') as f:
                f.write(report_str)
            self.logger.info(f"Report saved to {save_path}")
        
        return report_str


def run_sample_backtest():
    """
    Run a sample backtest with EMA crossover strategy on BTC/USDT.
    
    Returns:
        BacktestResult object
    """
    # Set up logging
    logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    
    # Create backtest config with current year dates
    current_year = datetime.datetime.now().year
    config = BacktestConfig(
        start_date=datetime.datetime(current_year-1, 1, 1),  # Last year January 1
        end_date=datetime.datetime(current_year-1, 12, 31),  # Last year December 31
        initial_capital=10000.0,
        symbols=["BTC/USDT"],
        timeframe=TimeFrame.DAY_1,
        strategy_name="EMA Crossover",
        market_type=MarketType.SPOT,
        leverage=1,
        commission_rate=0.001
    )
    
    # Create backtesting engine
    engine = BacktestingEngine(config)
    
    # Generate sample data
    engine.generate_sample_data("BTC/USDT", days=365)
    
    # Create strategy
    strategy = EMACrossoverStrategy(fast_period=12, slow_period=26)
    
    # Run backtest
    result = engine.run_backtest(strategy)
    
    # Generate plots
    os.makedirs("results", exist_ok=True)
    engine.plot_equity_curve(save_path="results/equity_curve.png")
    engine.plot_trades("BTC/USDT", save_path="results/trades.png")
    
    # Generate report
    report = engine.generate_report(save_path="results/backtest_report.md")
    
    return result


if __name__ == "__main__":
    result = run_sample_backtest()
    print(f"Backtest completed with {len(result.trades)} trades")
    print(f"Final capital: ${result.equity_curve[-1] if result.equity_curve else 0:.2f}")
    print(f"Total PnL: ${result.total_pnl:.2f} ({result.total_pnl_percentage:.2f}%)")
    print(f"Win rate: {result.win_rate * 100:.2f}%")
    print(f"Max drawdown: {result.max_drawdown_percentage:.2f}%")
    print(f"Sharpe ratio: {result.sharpe_ratio:.2f}")
