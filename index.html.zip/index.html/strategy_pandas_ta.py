"""
Strategy Module for Crypto Trading Bot (using pandas-ta instead of TA-Lib).

This module implements various trading strategies:
- EMA Crossover
- RSI Oversold/Overbought
- MACD Crossover
- Bollinger Bands
"""

import pandas as pd
import numpy as np
import pandas_ta as ta
from typing import Dict, List, Optional, Union, Tuple
import logging
from data_structures import OHLCV, TimeFrame


class Strategy:
    """Base class for trading strategies."""
    
    def __init__(self, name: str):
        """
        Initialize the strategy.
        
        Args:
            name: Strategy name
        """
        self.name = name
        self.logger = logging.getLogger(__name__)
    
    def generate_signals(self, ohlcv_df: pd.DataFrame) -> pd.DataFrame:
        """
        Generate trading signals from OHLCV data.
        
        Args:
            ohlcv_df: DataFrame with OHLCV data
            
        Returns:
            DataFrame with signals (1 for buy, -1 for sell, 0 for hold)
        """
        raise NotImplementedError("Subclasses must implement this method")
    
    def get_parameters(self) -> Dict[str, any]:
        """
        Get strategy parameters.
        
        Returns:
            Dictionary of parameter names and values
        """
        raise NotImplementedError("Subclasses must implement this method")
    
    def set_parameters(self, parameters: Dict[str, any]) -> None:
        """
        Set strategy parameters.
        
        Args:
            parameters: Dictionary of parameter names and values
        """
        raise NotImplementedError("Subclasses must implement this method")


class EMACrossoverStrategy(Strategy):
    """EMA Crossover strategy implementation."""
    
    def __init__(self, fast_period: int = 12, slow_period: int = 26):
        """
        Initialize the EMA Crossover strategy.
        
        Args:
            fast_period: Period for fast EMA
            slow_period: Period for slow EMA
        """
        super().__init__("EMA Crossover")
        self.fast_period = fast_period
        self.slow_period = slow_period
    
    def generate_signals(self, ohlcv_df: pd.DataFrame) -> pd.DataFrame:
        """
        Generate trading signals based on EMA crossover.
        
        Args:
            ohlcv_df: DataFrame with OHLCV data
            
        Returns:
            DataFrame with signals (1 for buy, -1 for sell, 0 for hold)
        """
        # Make a copy to avoid modifying the original DataFrame
        df = ohlcv_df.copy()
        
        # Calculate EMAs using pandas_ta
        df['ema_fast'] = df.ta.ema(length=self.fast_period)
        df['ema_slow'] = df.ta.ema(length=self.slow_period)
        
        # Calculate crossover signals
        df['signal'] = 0  # Initialize with no signal
        
        # Bullish crossover (fast crosses above slow)
        df.loc[(df['ema_fast'] > df['ema_slow']) & 
               (df['ema_fast'].shift(1) <= df['ema_slow'].shift(1)), 'signal'] = 1
        
        # Bearish crossover (fast crosses below slow)
        df.loc[(df['ema_fast'] < df['ema_slow']) & 
               (df['ema_fast'].shift(1) >= df['ema_slow'].shift(1)), 'signal'] = -1
        
        return df
    
    def get_parameters(self) -> Dict[str, any]:
        """
        Get strategy parameters.
        
        Returns:
            Dictionary of parameter names and values
        """
        return {
            'fast_period': self.fast_period,
            'slow_period': self.slow_period
        }
    
    def set_parameters(self, parameters: Dict[str, any]) -> None:
        """
        Set strategy parameters.
        
        Args:
            parameters: Dictionary of parameter names and values
        """
        if 'fast_period' in parameters:
            self.fast_period = parameters['fast_period']
        if 'slow_period' in parameters:
            self.slow_period = parameters['slow_period']


class RSIStrategy(Strategy):
    """RSI Overbought/Oversold strategy implementation."""
    
    def __init__(self, period: int = 14, oversold: int = 30, overbought: int = 70):
        """
        Initialize the RSI strategy.
        
        Args:
            period: Period for RSI calculation
            oversold: Oversold threshold
            overbought: Overbought threshold
        """
        super().__init__("RSI Strategy")
        self.period = period
        self.oversold = oversold
        self.overbought = overbought
    
    def generate_signals(self, ohlcv_df: pd.DataFrame) -> pd.DataFrame:
        """
        Generate trading signals based on RSI.
        
        Args:
            ohlcv_df: DataFrame with OHLCV data
            
        Returns:
            DataFrame with signals (1 for buy, -1 for sell, 0 for hold)
        """
        # Make a copy to avoid modifying the original DataFrame
        df = ohlcv_df.copy()
        
        # Calculate RSI using pandas_ta
        df['rsi'] = df.ta.rsi(length=self.period)
        
        # Calculate signals
        df['signal'] = 0  # Initialize with no signal
        
        # Buy when RSI crosses above oversold threshold
        df.loc[(df['rsi'] > self.oversold) & 
               (df['rsi'].shift(1) <= self.oversold), 'signal'] = 1
        
        # Sell when RSI crosses below overbought threshold
        df.loc[(df['rsi'] < self.overbought) & 
               (df['rsi'].shift(1) >= self.overbought), 'signal'] = -1
        
        return df
    
    def get_parameters(self) -> Dict[str, any]:
        """
        Get strategy parameters.
        
        Returns:
            Dictionary of parameter names and values
        """
        return {
            'period': self.period,
            'oversold': self.oversold,
            'overbought': self.overbought
        }
    
    def set_parameters(self, parameters: Dict[str, any]) -> None:
        """
        Set strategy parameters.
        
        Args:
            parameters: Dictionary of parameter names and values
        """
        if 'period' in parameters:
            self.period = parameters['period']
        if 'oversold' in parameters:
            self.oversold = parameters['oversold']
        if 'overbought' in parameters:
            self.overbought = parameters['overbought']


class MACDStrategy(Strategy):
    """MACD Crossover strategy implementation."""
    
    def __init__(self, fast_period: int = 12, slow_period: int = 26, signal_period: int = 9):
        """
        Initialize the MACD strategy.
        
        Args:
            fast_period: Fast period for MACD
            slow_period: Slow period for MACD
            signal_period: Signal period for MACD
        """
        super().__init__("MACD Strategy")
        self.fast_period = fast_period
        self.slow_period = slow_period
        self.signal_period = signal_period
    
    def generate_signals(self, ohlcv_df: pd.DataFrame) -> pd.DataFrame:
        """
        Generate trading signals based on MACD crossover.
        
        Args:
            ohlcv_df: DataFrame with OHLCV data
            
        Returns:
            DataFrame with signals (1 for buy, -1 for sell, 0 for hold)
        """
        # Make a copy to avoid modifying the original DataFrame
        df = ohlcv_df.copy()
        
        # Calculate MACD using pandas_ta
        macd = df.ta.macd(fast=self.fast_period, slow=self.slow_period, signal=self.signal_period)
        
        # Merge MACD results with original dataframe
        df = pd.concat([df, macd], axis=1)
        
        # Rename columns for clarity
        df.rename(columns={
            f'MACD_{self.fast_period}_{self.slow_period}_{self.signal_period}': 'macd',
            f'MACDs_{self.fast_period}_{self.slow_period}_{self.signal_period}': 'macd_signal',
            f'MACDh_{self.fast_period}_{self.slow_period}_{self.signal_period}': 'macd_hist'
        }, inplace=True)
        
        # Calculate signals
        df['signal'] = 0  # Initialize with no signal
        
        # Buy when MACD crosses above signal line
        df.loc[(df['macd'] > df['macd_signal']) & 
               (df['macd'].shift(1) <= df['macd_signal'].shift(1)), 'signal'] = 1
        
        # Sell when MACD crosses below signal line
        df.loc[(df['macd'] < df['macd_signal']) & 
               (df['macd'].shift(1) >= df['macd_signal'].shift(1)), 'signal'] = -1
        
        return df
    
    def get_parameters(self) -> Dict[str, any]:
        """
        Get strategy parameters.
        
        Returns:
            Dictionary of parameter names and values
        """
        return {
            'fast_period': self.fast_period,
            'slow_period': self.slow_period,
            'signal_period': self.signal_period
        }
    
    def set_parameters(self, parameters: Dict[str, any]) -> None:
        """
        Set strategy parameters.
        
        Args:
            parameters: Dictionary of parameter names and values
        """
        if 'fast_period' in parameters:
            self.fast_period = parameters['fast_period']
        if 'slow_period' in parameters:
            self.slow_period = parameters['slow_period']
        if 'signal_period' in parameters:
            self.signal_period = parameters['signal_period']


class BollingerBandsStrategy(Strategy):
    """Bollinger Bands strategy implementation."""
    
    def __init__(self, period: int = 20, std_dev: float = 2.0):
        """
        Initialize the Bollinger Bands strategy.
        
        Args:
            period: Period for moving average
            std_dev: Number of standard deviations for bands
        """
        super().__init__("Bollinger Bands Strategy")
        self.period = period
        self.std_dev = std_dev
    
    def generate_signals(self, ohlcv_df: pd.DataFrame) -> pd.DataFrame:
        """
        Generate trading signals based on Bollinger Bands.
        
        Args:
            ohlcv_df: DataFrame with OHLCV data
            
        Returns:
            DataFrame with signals (1 for buy, -1 for sell, 0 for hold)
        """
        # Make a copy to avoid modifying the original DataFrame
        df = ohlcv_df.copy()
        
        # Calculate Bollinger Bands using pandas_ta
        bbands = df.ta.bbands(length=self.period, std=self.std_dev)
        
        # Merge Bollinger Bands results with original dataframe
        df = pd.concat([df, bbands], axis=1)
        
        # Rename columns for clarity
        df.rename(columns={
            f'BBL_{self.period}_{self.std_dev}': 'bb_lower',
            f'BBM_{self.period}_{self.std_dev}': 'bb_middle',
            f'BBU_{self.period}_{self.std_dev}': 'bb_upper',
            f'BBB_{self.period}_{self.std_dev}': 'bb_bandwidth',
            f'BBP_{self.period}_{self.std_dev}': 'bb_percent'
        }, inplace=True)
        
        # Calculate signals
        df['signal'] = 0  # Initialize with no signal
        
        # Buy when price crosses above lower band
        df.loc[(df['close'] > df['bb_lower']) & 
               (df['close'].shift(1) <= df['bb_lower'].shift(1)), 'signal'] = 1
        
        # Sell when price crosses below upper band
        df.loc[(df['close'] < df['bb_upper']) & 
               (df['close'].shift(1) >= df['bb_upper'].shift(1)), 'signal'] = -1
        
        return df
    
    def get_parameters(self) -> Dict[str, any]:
        """
        Get strategy parameters.
        
        Returns:
            Dictionary of parameter names and values
        """
        return {
            'period': self.period,
            'std_dev': self.std_dev
        }
    
    def set_parameters(self, parameters: Dict[str, any]) -> None:
        """
        Set strategy parameters.
        
        Args:
            parameters: Dictionary of parameter names and values
        """
        if 'period' in parameters:
            self.period = parameters['period']
        if 'std_dev' in parameters:
            self.std_dev = parameters['std_dev']


def create_strategy(strategy_name: str, parameters: Optional[Dict[str, any]] = None) -> Strategy:
    """
    Factory function to create a strategy instance.
    
    Args:
        strategy_name: Name of the strategy
        parameters: Optional parameters for the strategy
        
    Returns:
        Strategy instance
        
    Raises:
        ValueError: If strategy is not supported
    """
    strategies = {
        'ema_crossover': EMACrossoverStrategy,
        'rsi': RSIStrategy,
        'macd': MACDStrategy,
        'bollinger_bands': BollingerBandsStrategy
    }
    
    if strategy_name.lower() not in strategies:
        raise ValueError(f"Strategy '{strategy_name}' not supported. Available strategies: {list(strategies.keys())}")
    
    strategy_class = strategies[strategy_name.lower()]
    strategy = strategy_class()
    
    if parameters:
        strategy.set_parameters(parameters)
    
    return strategy
