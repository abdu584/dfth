"""
Data structures for the Crypto Trading Bot.

This module defines the data structures used throughout the bot:
- OHLCV: Open, High, Low, Close, Volume data
- Order: Trading order
- Trade: Completed trade
- BacktestConfig: Configuration for backtesting
- BacktestResult: Results of a backtest
"""

from dataclasses import dataclass, field
from typing import List, Dict, Optional, Union, Any
from enum import Enum
import pandas as pd
import datetime

class TimeFrame(Enum):
    """Timeframe for OHLCV data."""
    MINUTE_1 = '1m'
    MINUTE_5 = '5m'
    MINUTE_15 = '15m'
    HOUR_1 = '1h'
    HOUR_4 = '4h'
    DAY_1 = '1d'

class TradeSide(Enum):
    """Side of a trade."""
    BUY = 'buy'
    SELL = 'sell'

class OrderType(Enum):
    """Type of order."""
    MARKET = 'market'
    LIMIT = 'limit'
    STOP = 'stop'
    STOP_LIMIT = 'stop_limit'

class MarketType(Enum):
    """Type of market."""
    SPOT = 'spot'
    FUTURES = 'futures'

@dataclass
class OHLCV:
    """Open, High, Low, Close, Volume data."""
    symbol: str
    timeframe: TimeFrame
    timestamp: List[int]
    open: List[float]
    high: List[float]
    low: List[float]
    close: List[float]
    volume: List[float]
    
    def to_dataframe(self) -> pd.DataFrame:
        """
        Convert OHLCV data to pandas DataFrame.
        
        Returns:
            DataFrame with OHLCV data
        """
        df = pd.DataFrame({
            'open': self.open,
            'high': self.high,
            'low': self.low,
            'close': self.close,
            'volume': self.volume
        }, index=[datetime.datetime.fromtimestamp(ts/1000) for ts in self.timestamp])
        
        return df

@dataclass
class Order:
    """Trading order."""
    symbol: str
    side: TradeSide
    order_type: OrderType
    quantity: float
    price: float
    leverage: int = 1
    timestamp: int = 0
    status: str = 'new'
    filled_quantity: float = 0
    average_fill_price: float = 0
    commission: float = 0
    order_id: str = ''

@dataclass
class Trade:
    """Completed trade."""
    symbol: str
    entry_order: Order
    exit_order: Optional[Order]
    pnl: float
    pnl_percentage: float
    duration: int  # in milliseconds
    strategy_name: str

@dataclass
class BacktestConfig:
    """Configuration for backtesting."""
    start_date: datetime.datetime
    end_date: datetime.datetime
    initial_capital: float
    symbols: List[str]
    timeframe: TimeFrame
    strategy_name: str
    market_type: MarketType = MarketType.SPOT
    leverage: int = 1
    commission_rate: float = 0.001

@dataclass
class BacktestResult:
    """Results of a backtest."""
    config: BacktestConfig
    trades: List[Trade]
    equity_curve: List[float]
    timestamps: List[int]
    total_pnl: float
    total_pnl_percentage: float
    win_count: int
    loss_count: int
    win_rate: float
    max_drawdown: float
    max_drawdown_percentage: float
    sharpe_ratio: float
    sortino_ratio: float
    profit_factor: float
