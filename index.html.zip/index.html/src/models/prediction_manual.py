"""
Prediction Engine Implementation for Crypto Trading Bot.

This module implements the prediction engine functionality:
- Loading historical data
- Calculating technical indicators
- Generating predictions for rising/falling assets
- Outputting confidence scores
"""

import pandas as pd
import numpy as np
from typing import Dict, List, Optional, Union, Tuple, Any
import datetime
import logging
import os
from pathlib import Path
import json
import matplotlib.pyplot as plt
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler

# Update import to use absolute path
from src.models.data_structures import OHLCV, TimeFrame

class Predictor:
    """Base class for all predictors."""
    
    def __init__(self):
        """Initialize the predictor."""
        self.logger = logging.getLogger(__name__)
    
    def predict(self, df: pd.DataFrame) -> Dict[str, Any]:
        """
        Generate prediction for the given data.
        
        Args:
            df: DataFrame with OHLCV data and features
            
        Returns:
            Dictionary with prediction results
        """
        raise NotImplementedError("Subclasses must implement predict")


class TechnicalIndicatorPredictor(Predictor):
    """Predictor using technical indicators."""
    
    def __init__(self):
        """Initialize the technical indicator predictor."""
        super().__init__()
    
    def predict(self, df: pd.DataFrame) -> Dict[str, Any]:
        """
        Generate prediction based on technical indicators.
        
        Args:
            df: DataFrame with OHLCV data
            
        Returns:
            Dictionary with prediction results
        """
        # Calculate technical indicators
        df = self._calculate_indicators(df)
        
        # Get the latest values
        latest = df.iloc[-1]
        
        # Determine prediction
        prediction = {}
        
        # RSI
        rsi = latest['rsi_14']
        prediction['rsi'] = rsi
        
        # MACD
        macd = latest['macd']
        prediction['macd'] = macd
        
        # Bollinger Bands
        bb_position = latest['bb_position']
        prediction['bb_position'] = bb_position
        
        # Determine if bullish or bearish
        is_bullish = (rsi < 30 and rsi > 20) or (macd > 0 and macd > latest['macd_signal']) or (bb_position < 0.2)
        is_bearish = (rsi > 70 and rsi < 80) or (macd < 0 and macd < latest['macd_signal']) or (bb_position > 0.8)
        
        # Calculate confidence
        if is_bullish:
            confidence = 0.5 + (0.5 * (
                (0.3 if rsi < 30 and rsi > 20 else 0) +
                (0.4 if macd > 0 and macd > latest['macd_signal'] else 0) +
                (0.3 if bb_position < 0.2 else 0)
            ))
            prediction['direction'] = 'bullish'
        elif is_bearish:
            confidence = 0.5 + (0.5 * (
                (0.3 if rsi > 70 and rsi < 80 else 0) +
                (0.4 if macd < 0 and macd < latest['macd_signal'] else 0) +
                (0.3 if bb_position > 0.8 else 0)
            ))
            prediction['direction'] = 'bearish'
        else:
            confidence = 0.5
            prediction['direction'] = 'neutral'
        
        prediction['confidence'] = confidence
        
        return prediction
    
    def _calculate_indicators(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Calculate technical indicators.
        
        Args:
            df: DataFrame with OHLCV data
            
        Returns:
            DataFrame with technical indicators
        """
        # Make a copy of the dataframe
        df = df.copy()
        
        # RSI (14)
        df['rsi_14'] = self._calculate_rsi(df['close'], 14)
        
        # MACD
        ema_12 = self._calculate_ema(df['close'], 12)
        ema_26 = self._calculate_ema(df['close'], 26)
        df['macd'] = ema_12 - ema_26
        df['macd_signal'] = self._calculate_ema(df['macd'], 9)
        df['macd_hist'] = df['macd'] - df['macd_signal']
        
        # Bollinger Bands
        df['bb_middle'] = df['close'].rolling(window=20).mean()
        df['bb_std'] = df['close'].rolling(window=20).std()
        df['bb_upper'] = df['bb_middle'] + (df['bb_std'] * 2)
        df['bb_lower'] = df['bb_middle'] - (df['bb_std'] * 2)
        
        # Bollinger Band position (0 = at lower band, 1 = at upper band)
        df['bb_position'] = (df['close'] - df['bb_lower']) / (df['bb_upper'] - df['bb_lower'])
        
        return df
    
    def _calculate_rsi(self, series: pd.Series, period: int) -> pd.Series:
        """
        Calculate Relative Strength Index.
        
        Args:
            series: Series of values
            period: RSI period
            
        Returns:
            Series with RSI values
        """
        # Calculate price changes
        delta = series.diff()
        
        # Separate gains and losses
        gain = delta.copy()
        loss = delta.copy()
        gain[gain < 0] = 0
        loss[loss > 0] = 0
        loss = abs(loss)
        
        # Calculate average gain and loss
        avg_gain = gain.rolling(window=period).mean()
        avg_loss = loss.rolling(window=period).mean()
        
        # Calculate RS and RSI
        rs = avg_gain / avg_loss
        rsi = 100 - (100 / (1 + rs))
        
        return rsi
    
    def _calculate_ema(self, series: pd.Series, period: int) -> pd.Series:
        """
        Calculate Exponential Moving Average.
        
        Args:
            series: Series of values
            period: EMA period
            
        Returns:
            Series with EMA values
        """
        # Calculate multiplier
        multiplier = 2 / (period + 1)
        
        # Calculate EMA
        ema = series.copy()
        ema.iloc[0:period] = series.iloc[0:period].mean()
        
        for i in range(period, len(series)):
            ema.iloc[i] = (series.iloc[i] * multiplier) + (ema.iloc[i-1] * (1 - multiplier))
        
        return ema


class MachineLearningPredictor(Predictor):
    """Predictor using machine learning."""
    
    def __init__(self):
        """Initialize the machine learning predictor."""
        super().__init__()
        self.model = RandomForestClassifier(n_estimators=100, random_state=42)
        self.scaler = StandardScaler()
        self.is_trained = False
    
    def train(self, df: pd.DataFrame, window: int = 14) -> None:
        """
        Train the machine learning model.
        
        Args:
            df: DataFrame with OHLCV data
            window: Window size for feature generation
        """
        # Calculate features
        df = self._calculate_features(df, window)
        
        # Drop NaN values
        df = df.dropna()
        
        # Generate labels
        df['target'] = 0
        df['future_return'] = df['close'].pct_change(window).shift(-window)
        df.loc[df['future_return'] > 0.02, 'target'] = 1  # Bullish if future return > 2%
        df.loc[df['future_return'] < -0.02, 'target'] = -1  # Bearish if future return < -2%
        
        # Drop NaN values again
        df = df.dropna()
        
        # Select features
        features = [col for col in df.columns if col.startswith('feature_')]
        X = df[features].values
        y = df['target'].values
        
        # Scale features
        X = self.scaler.fit_transform(X)
        
        # Train model
        self.model.fit(X, y)
        self.is_trained = True
        
        self.logger.info(f"Model trained with {len(X)} samples")
    
    def predict(self, df: pd.DataFrame, window: int = 14) -> Dict[str, Any]:
        """
        Generate prediction using the machine learning model.
        
        Args:
            df: DataFrame with OHLCV data
            window: Window size for feature generation
            
        Returns:
            Dictionary with prediction results
        """
        if not self.is_trained:
            self.logger.warning("Model not trained, using random prediction")
            return {
                'direction': np.random.choice(['bullish', 'bearish', 'neutral']),
                'confidence': np.random.uniform(0.5, 1.0)
            }
        
        # Calculate features
        df = self._calculate_features(df, window)
        
        # Drop NaN values
        df = df.dropna()
        
        # Select features
        features = [col for col in df.columns if col.startswith('feature_')]
        X = df[features].iloc[-1:].values
        
        # Scale features
        X = self.scaler.transform(X)
        
        # Predict
        prediction = self.model.predict(X)[0]
        probabilities = self.model.predict_proba(X)[0]
        
        # Determine direction and confidence
        if prediction == 1:
            direction = 'bullish'
            confidence = probabilities[np.where(self.model.classes_ == 1)[0][0]]
        elif prediction == -1:
            direction = 'bearish'
            confidence = probabilities[np.where(self.model.classes_ == -1)[0][0]]
        else:
            direction = 'neutral'
            confidence = probabilities[np.where(self.model.classes_ == 0)[0][0]]
        
        return {
            'direction': direction,
            'confidence': confidence
        }
    
    def _calculate_features(self, df: pd.DataFrame, window: int = 14) -> pd.DataFrame:
        """
        Calculate features for machine learning.
        
        Args:
            df: DataFrame with OHLCV data
            window: Window size for feature generation
            
        Returns:
            DataFrame with features
        """
        # Make a copy of the dataframe
        df = df.copy()
        
        # Price features
        df['feature_return'] = df['close'].pct_change(1)
        df['feature_return_5'] = df['close'].pct_change(5)
        df['feature_return_10'] = df['close'].pct_change(10)
        df['feature_return_20'] = df['close'].pct_change(20)
        
        # Volume features
        df['feature_volume_change'] = df['volume'].pct_change(1)
        df['feature_volume_ma_ratio'] = df['volume'] / df['volume'].rolling(window=window).mean()
        
        # Technical indicators
        df['feature_rsi'] = self._calculate_rsi(df['close'], window)
        
        ema_fast = self._calculate_ema(df['close'], int(window/2))
        ema_slow = self._calculate_ema(df['close'], window)
        df['feature_macd'] = ema_fast - ema_slow
        df['feature_macd_signal'] = self._calculate_ema(df['feature_macd'], int(window/3))
        df['feature_macd_hist'] = df['feature_macd'] - df['feature_macd_signal']
        
        df['feature_bb_middle'] = df['close'].rolling(window=window).mean()
        df['feature_bb_std'] = df['close'].rolling(window=window).std()
        df['feature_bb_upper'] = df['feature_bb_middle'] + (df['feature_bb_std'] * 2)
        df['feature_bb_lower'] = df['feature_bb_middle'] - (df['feature_bb_std'] * 2)
        df['feature_bb_position'] = (df['close'] - df['feature_bb_lower']) / (df['feature_bb_upper'] - df['feature_bb_lower'])
        
        return df
    
    def _calculate_rsi(self, series: pd.Series, period: int) -> pd.Series:
        """
        Calculate Relative Strength Index.
        
        Args:
            series: Series of values
            period: RSI period
            
        Returns:
            Series with RSI values
        """
        # Calculate price changes
        delta = series.diff()
        
        # Separate gains and losses
        gain = delta.copy()
        loss = delta.copy()
        gain[gain < 0] = 0
        loss[loss > 0] = 0
        loss = abs(loss)
        
        # Calculate average gain and loss
        avg_gain = gain.rolling(window=period).mean()
        avg_loss = loss.rolling(window=period).mean()
        
        # Calculate RS and RSI
        rs = avg_gain / avg_loss
        rsi = 100 - (100 / (1 + rs))
        
        return rsi
    
    def _calculate_ema(self, series: pd.Series, period: int) -> pd.Series:
        """
        Calculate Exponential Moving Average.
        
        Args:
            series: Series of values
            period: EMA period
            
        Returns:
            Series with EMA values
        """
        # Calculate multiplier
        multiplier = 2 / (period + 1)
        
        # Calculate EMA
        ema = series.copy()
        ema.iloc[0:period] = series.iloc[0:period].mean()
        
        for i in range(period, len(series)):
            ema.iloc[i] = (series.iloc[i] * multiplier) + (ema.iloc[i-1] * (1 - multiplier))
        
        return ema


class PredictionEngine:
    """Engine for generating predictions."""
    
    def __init__(self, predictor: Predictor):
        """
        Initialize the prediction engine.
        
        Args:
            predictor: Predictor to use for generating predictions
        """
        self.predictor = predictor
        self.data = {}  # Dict to store OHLCV data for each symbol
        self.logger = logging.getLogger(__name__)
    
    def load_data(self, data_dict: Dict[str, OHLCV]) -> None:
        """
        Load OHLCV data for prediction.
        
        Args:
            data_dict: Dictionary mapping symbols to OHLCV objects
        """
        self.data = data_dict
        self.logger.info(f"Loaded data for {len(data_dict)} symbols")
    
    def load_csv_data(self, csv_path: str, symbol: str) -> None:
        """
        Load OHLCV data from CSV file.
        
        Args:
            csv_path: Path to CSV file
            symbol: Symbol for the data
        """
        df = pd.read_csv(csv_path)
        
        # Convert timestamp to datetime if needed
        if 'timestamp' in df.columns:
            if isinstance(df['timestamp'].iloc[0], str):
                df['timestamp'] = pd.to_datetime(df['timestamp']).astype(np.int64) // 10**6
        elif 'datetime' in df.columns:
            df['timestamp'] = pd.to_datetime(df['datetime']).astype(np.int64) // 10**6
        
        # Ensure required columns exist
        required_columns = ['timestamp', 'open', 'high', 'low', 'close', 'volume']
        for col in required_columns:
            if col not in df.columns:
                raise ValueError(f"Required column '{col}' not found in CSV file")
        
        # Create OHLCV object
        ohlcv = OHLCV(
            symbol=symbol,
            timeframe=TimeFrame.DAY_1,  # Default to daily timeframe
            timestamp=df['timestamp'].tolist(),
            open=df['open'].tolist(),
            high=df['high'].tolist(),
            low=df['low'].tolist(),
            close=df['close'].tolist(),
            volume=df['volume'].tolist()
        )
        
        self.data[symbol] = ohlcv
        self.logger.info(f"Loaded data for {symbol} from CSV file")
    
    def generate_sample_data(self, symbol: str, days: int = 30) -> None:
        """
        Generate sample OHLCV data for testing.
        
        Args:
            symbol: Symbol for the data
            days: Number of days of data to generate
        """
        # Generate timestamps
        end_date = datetime.datetime.now()
        start_date = end_date - datetime.timedelta(days=days)
        
        timestamps = []
        current_date = start_date
        while current_date <= end_date:
            timestamps.append(int(current_date.timestamp() * 1000))
            current_date += datetime.timedelta(days=1)
        
        # Generate price data with random walk
        n = len(timestamps)
        close = [10000]  # Start price
        for i in range(1, n):
            # Random daily return between -3% and +3%
            daily_return = np.random.normal(0.0005, 0.02)
            close.append(close[-1] * (1 + daily_return))
        
        # Generate OHLC based on close prices
        open_prices = [close[0]] + close[:-1]
        high = [c * (1 + abs(np.random.normal(0, 0.01))) for c in close]
        low = [c * (1 - abs(np.random.normal(0, 0.01))) for c in close]
        
        # Generate volume
        volume = [abs(np.random.normal(1000, 500)) * c for c in close]
        
        # Create OHLCV object
        ohlcv = OHLCV(
            symbol=symbol,
            timeframe=TimeFrame.DAY_1,
            timestamp=timestamps,
            open=open_prices,
            high=high,
            low=low,
            close=close,
            volume=volume
        )
        
        self.data[symbol] = ohlcv
        self.logger.info(f"Generated sample data for {symbol}")
    
    def generate_predictions(self, symbols: List[str], window: int = 14, confidence_threshold: float = 0.7) -> Dict[str, Dict[str, Any]]:
        """
        Generate predictions for the specified symbols.
        
        Args:
            symbols: List of symbols to generate predictions for
            window: Window size for feature generation
            confidence_threshold: Minimum confidence threshold for predictions
            
        Returns:
            Dictionary mapping symbols to prediction results
        """
        predictions = {}
        
        for symbol in symbols:
            if symbol not in self.data:
                self.logger.warning(f"No data for symbol {symbol}, skipping")
                continue
            
            # Convert OHLCV to DataFrame
            ohlcv_df = self.data[symbol].to_dataframe()
            
            # Generate prediction
            prediction = self.predictor.predict(ohlcv_df)
            
            # Log prediction
            self.logger.info(f"Prediction for {symbol}: {prediction['direction']} with confidence {prediction['confidence']:.4f}")
            
            # Add to predictions if confidence is above threshold
            if prediction['confidence'] >= confidence_threshold:
                predictions[symbol] = prediction
            
        return predictions
    
    def get_top_predictions(self, predictions: Dict[str, Dict[str, Any]], n: int = 3) -> Tuple[List[Tuple[str, Dict[str, Any]]], List[Tuple[str, Dict[str, Any]]]]:
        """
        Get top bullish and bearish predictions.
        
        Args:
            predictions: Dictionary mapping symbols to prediction results
            n: Number of top predictions to return
            
        Returns:
            Tuple of (top bullish predictions, top bearish predictions)
        """
        bullish = []
        bearish = []
        
        for symbol, prediction in predictions.items():
            if prediction['direction'] == 'bullish':
                bullish.append((symbol, prediction))
            elif prediction['direction'] == 'bearish':
                bearish.append((symbol, prediction))
        
        # Sort by confidence
        bullish.sort(key=lambda x: x[1]['confidence'], reverse=True)
        bearish.sort(key=lambda x: x[1]['confidence'], reverse=True)
        
        # Get top n
        top_bullish = bullish[:n]
        top_bearish = bearish[:n]
        
        # Log top predictions
        self.logger.info("Top Bullish Predictions:")
        for symbol, prediction in top_bullish:
            self.logger.info(f"{symbol}: Confidence {prediction['confidence']:.4f}")
        
        self.logger.info("Top Bearish Predictions:")
        for symbol, prediction in top_bearish:
            self.logger.info(f"{symbol}: Confidence {prediction['confidence']:.4f}")
        
        return top_bullish, top_bearish
    
    def plot_predictions(self, predictions: Dict[str, Dict[str, Any]], save_path: Optional[str] = None) -> None:
        """
        Plot prediction confidence scores.
        
        Args:
            predictions: Dictionary mapping symbols to prediction results
            save_path: Optional path to save the plot
        """
        # Prepare data
        symbols = []
        confidences = []
        colors = []
        
        for symbol, prediction in predictions.items():
            symbols.append(symbol)
            confidences.append(prediction['confidence'])
            
            if prediction['direction'] == 'bullish':
                colors.append('green')
            elif prediction['direction'] == 'bearish':
                colors.append('red')
            else:
                colors.append('gray')
        
        # Create figure
        plt.figure(figsize=(12, 6))
        
        # Create bar chart
        bars = plt.bar(symbols, confidences, color=colors)
        
        # Add labels and title
        plt.xlabel('Symbol')
        plt.ylabel('Confidence Score')
        plt.title('Prediction Confidence Scores')
        plt.ylim(0, 1)
        plt.grid(axis='y', linestyle='--', alpha=0.7)
        
        # Add legend
        from matplotlib.patches import Patch
        legend_elements = [
            Patch(facecolor='green', label='Bullish'),
            Patch(facecolor='red', label='Bearish'),
            Patch(facecolor='gray', label='Neutral')
        ]
        plt.legend(handles=legend_elements)
        
        # Rotate x-axis labels
        plt.xticks(rotation=45)
        
        # Adjust layout
        plt.tight_layout()
        
        # Save or show
        if save_path:
            plt.savefig(save_path)
            self.logger.info(f"Prediction plot saved to {save_path}")
        else:
            plt.show()


def run_sample_prediction():
    """
    Run a sample prediction for demonstration.
    
    Returns:
        Tuple of (top bullish predictions, top bearish predictions)
    """
    # Set up logging
    logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    logger = logging.getLogger(__name__)
    
    # Create symbols list
    symbols = [
        "BTC/USDT", "ETH/USDT", "SOL/USDT", "BNB/USDT", "ADA/USDT",
        "XRP/USDT", "DOT/USDT", "DOGE/USDT", "AVAX/USDT", "MATIC/USDT"
    ]
    
    logger.info("Generating sample data...")
    
    # Create prediction engine with technical indicator predictor
    predictor = TechnicalIndicatorPredictor()
    
    logger.info("Creating prediction engine...")
    engine = PredictionEngine(predictor)
    
    # Generate sample data for each symbol
    for symbol in symbols:
        engine.generate_sample_data(symbol, days=30)
    
    logger.info("Generating predictions...")
    
    # Generate predictions
    predictions = engine.generate_predictions(symbols, window=14, confidence_threshold=0.5)
    
    logger.info("Getting top predictions...")
    
    # Get top predictions
    top_bullish, top_bearish = engine.get_top_predictions(predictions, n=3)
    
    # Generate visualization
    os.makedirs("results", exist_ok=True)
    engine.plot_predictions(predictions, save_path="results/predictions.png")
    
    # Save predictions to file
    with open("results/predictions.txt", "w") as f:
        f.write("Top Bullish Predictions:\n")
        for symbol, prediction in top_bullish:
            f.write(f"{symbol}: Confidence {prediction['confidence']:.4f}\n")
            f.write(f"  Key Indicators: RSI={prediction.get('rsi', 'N/A'):.2f}, MACD={prediction.get('macd', 'N/A'):.2f}\n")
        
        f.write("\nTop Bearish Predictions:\n")
        for symbol, prediction in top_bearish:
            f.write(f"{symbol}: Confidence {prediction['confidence']:.4f}\n")
            f.write(f"  Key Indicators: RSI={prediction.get('rsi', 'N/A'):.2f}, MACD={prediction.get('macd', 'N/A'):.2f}\n")
    
    return top_bullish, top_bearish


if __name__ == "__main__":
    top_bullish, top_bearish = run_sample_prediction()
    print("Prediction completed successfully!")
