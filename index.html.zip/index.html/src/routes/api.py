"""
API routes for the Flask application.
This file contains the main API blueprint and general API endpoints.
"""

from flask import Blueprint, jsonify, request
import logging
import os
import json
from datetime import datetime

# Create blueprint
api_bp = Blueprint('api', __name__)

# Set up logging
logger = logging.getLogger(__name__)

@api_bp.route('/', methods=['GET'])
def api_index():
    """API index endpoint that returns available endpoints."""
    return jsonify({
        'status': 'success',
        'message': 'Crypto Trading Bot API',
        'endpoints': [
            '/api/backtest',
            '/api/predict',
            '/api/config/api',
            '/api/config/trading',
            '/api/dashboard'
        ]
    })

@api_bp.route('/status', methods=['GET'])
def api_status():
    """API status endpoint that returns the current status of the bot."""
    try:
        # Get the status of the bot
        status = {
            'status': 'online',
            'version': '1.0.0',
            'timestamp': datetime.now().isoformat(),
            'services': {
                'backtest': 'available',
                'prediction': 'available',
                'trading': 'disabled'  # Default to disabled for safety
            }
        }
        
        # Check if trading is enabled in config
        config_path = os.path.join(os.path.dirname(__file__), '..', '..', 'data', 'trading_config.json')
        if os.path.exists(config_path):
            try:
                with open(config_path, 'r') as f:
                    trading_config = json.load(f)
                    status['services']['trading'] = 'enabled' if trading_config.get('enableLiveTrading', False) else 'disabled'
            except Exception as e:
                logger.error(f"Error reading trading config: {str(e)}")
        
        return jsonify(status)
    except Exception as e:
        logger.error(f"Error getting API status: {str(e)}")
        return jsonify({'error': str(e)}), 500
