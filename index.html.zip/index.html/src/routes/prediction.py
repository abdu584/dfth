"""
Prediction API routes for the Flask application.
This file contains the prediction blueprint and endpoints for generating predictions.
"""

from flask import Blueprint, jsonify, request
import logging
import os
import json
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import sys
import traceback

# Import bot modules from local models directory
from src.models.prediction_manual import PredictionEngine, TechnicalIndicatorPredictor

# Create blueprint
prediction_bp = Blueprint('prediction', __name__)

# Set up logging
logger = logging.getLogger(__name__)

@prediction_bp.route('/', methods=['POST'])
def generate_predictions():
    """
    Generate predictions for the provided symbols.
    
    Expected JSON payload:
    {
        "symbols": ["BTC/USDT", "ETH/USDT", "SOL/USDT"],
        "predictionWindow": 7,
        "confidenceThreshold": 0.7,
        "topN": 3
    }
    """
    try:
        # Get request data
        data = request.json
        if not data:
            return jsonify({'error': 'No data provided'}), 400
        
        # Validate required fields
        required_fields = ['symbols', 'predictionWindow', 'confidenceThreshold', 'topN']
        for field in required_fields:
            if field not in data:
                return jsonify({'error': f'Missing required field: {field}'}), 400
        
        # Create prediction engine
        predictor = TechnicalIndicatorPredictor()
        engine = PredictionEngine(predictor)
        
        # Generate sample data for each symbol
        for symbol in data['symbols']:
            engine.generate_sample_data(symbol, days=int(data['predictionWindow']))
        
        # Generate predictions
        predictions = engine.generate_predictions(
            symbols=data['symbols'],
            window=int(data['predictionWindow']),
            confidence_threshold=float(data['confidenceThreshold'])
        )
        
        # Get top N predictions
        top_bullish, top_bearish = engine.get_top_predictions(
            predictions=predictions,
            n=int(data['topN'])
        )
        
        # Generate visualization
        chart_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'static', 'img', 'predictions.png')
        generate_prediction_chart(top_bullish, top_bearish, chart_path)
        
        # Save predictions to file
        save_predictions(top_bullish, top_bearish)
        
        # Format response
        response = {
            'success': True,
            'bullish': format_predictions(top_bullish),
            'bearish': format_predictions(top_bearish),
            'images': {
                'predictions': '/static/img/predictions.png'
            }
        }
        
        return jsonify(response)
    except Exception as e:
        logger.error(f"Error generating predictions: {str(e)}")
        logger.error(traceback.format_exc())
        return jsonify({'error': str(e)}), 500

def format_predictions(predictions):
    """Format predictions for JSON response."""
    formatted_predictions = []
    for symbol, prediction in predictions:
        formatted_predictions.append({
            'symbol': symbol,
            'confidence': prediction['confidence'],
            'features': {
                'rsi_14': prediction.get('rsi', None),
                'macd': prediction.get('macd', None),
                'bb_position': prediction.get('bb_position', None)
            }
        })
    return formatted_predictions

def generate_prediction_chart(bullish_predictions, bearish_predictions, save_path):
    """Generate a chart visualizing the predictions."""
    # Prepare data
    symbols = []
    confidences = []
    colors = []
    
    # Add bullish predictions
    for symbol, prediction in bullish_predictions:
        symbols.append(symbol)
        confidences.append(prediction['confidence'])
        colors.append('#10b981')  # Green for bullish
    
    # Add bearish predictions
    for symbol, prediction in bearish_predictions:
        symbols.append(symbol)
        confidences.append(prediction['confidence'])
        colors.append('#ef4444')  # Red for bearish
    
    # Create figure
    plt.figure(figsize=(12, 6))
    
    # Create bar chart
    bars = plt.bar(symbols, confidences, color=colors)
    
    # Add labels and title
    plt.xlabel('Symbol')
    plt.ylabel('Confidence Score')
    plt.title('Prediction Confidence Scores')
    plt.ylim(0, 1)
    plt.grid(axis='y', linestyle='--', alpha=0.7)
    
    # Add legend
    from matplotlib.patches import Patch
    legend_elements = [
        Patch(facecolor='#10b981', label='Bullish'),
        Patch(facecolor='#ef4444', label='Bearish')
    ]
    plt.legend(handles=legend_elements)
    
    # Rotate x-axis labels
    plt.xticks(rotation=45)
    
    # Adjust layout
    plt.tight_layout()
    
    # Save figure
    plt.savefig(save_path)
    plt.close()
    
    logger.info(f"Prediction chart saved to {save_path}")

def save_predictions(bullish_predictions, bearish_predictions):
    """Save predictions to file for later reference."""
    data_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), 'data')
    os.makedirs(data_dir, exist_ok=True)
    
    result_path = os.path.join(data_dir, 'latest_predictions.json')
    
    # Format predictions for saving
    result = {
        'timestamp': datetime.now().isoformat(),
        'bullish': format_predictions(bullish_predictions),
        'bearish': format_predictions(bearish_predictions)
    }
    
    with open(result_path, 'w') as f:
        json.dump(result, f, indent=2)
    
    logger.info(f"Predictions saved to {result_path}")
    
    # Also save as text file for easy reading
    text_path = os.path.join(data_dir, 'latest_predictions.txt')
    
    with open(text_path, 'w') as f:
        f.write("Top Bullish Predictions:\n")
        for symbol, prediction in bullish_predictions:
            f.write(f"{symbol}: Confidence {prediction['confidence']:.4f}\n")
            f.write(f"  Key Indicators: RSI={prediction.get('rsi', 'N/A'):.2f}, MACD={prediction.get('macd', 'N/A'):.2f}\n")
        
        f.write("\nTop Bearish Predictions:\n")
        for symbol, prediction in bearish_predictions:
            f.write(f"{symbol}: Confidence {prediction['confidence']:.4f}\n")
            f.write(f"  Key Indicators: RSI={prediction.get('rsi', 'N/A'):.2f}, MACD={prediction.get('macd', 'N/A'):.2f}\n")
    
    logger.info(f"Predictions text saved to {text_path}")
