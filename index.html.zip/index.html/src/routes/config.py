"""
Configuration API routes for the Flask application.
This file contains the configuration blueprint and endpoints for managing bot settings.
"""

from flask import Blueprint, jsonify, request
import logging
import os
import json
from datetime import datetime
import sys
import traceback

# Create blueprint
config_bp = Blueprint('config', __name__)

# Set up logging
logger = logging.getLogger(__name__)

@config_bp.route('/api', methods=['POST'])
def save_api_config():
    """
    Save API configuration for exchange connections.
    
    Expected JSON payload:
    {
        "exchange": "binance",
        "apiKey": "your-api-key",
        "apiSecret": "your-api-secret",
        "testnet": true
    }
    """
    try:
        # Get request data
        data = request.json
        if not data:
            return jsonify({'error': 'No data provided'}), 400
        
        # Validate required fields
        required_fields = ['exchange', 'apiKey', 'apiSecret']
        for field in required_fields:
            if field not in data:
                return jsonify({'error': f'Missing required field: {field}'}), 400
        
        # Create data directory if it doesn't exist
        data_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), 'data')
        os.makedirs(data_dir, exist_ok=True)
        
        # Save API config
        config_path = os.path.join(data_dir, 'api_config.json')
        
        # Add timestamp
        data['timestamp'] = datetime.now().isoformat()
        
        with open(config_path, 'w') as f:
            # Mask API secret in logs
            log_data = data.copy()
            if 'apiSecret' in log_data:
                log_data['apiSecret'] = '***********'
            logger.info(f"Saving API config: {log_data}")
            
            json.dump(data, f, indent=2)
        
        return jsonify({'success': True, 'message': 'API configuration saved successfully'})
    except Exception as e:
        logger.error(f"Error saving API config: {str(e)}")
        logger.error(traceback.format_exc())
        return jsonify({'error': str(e)}), 500

@config_bp.route('/trading', methods=['POST'])
def save_trading_config():
    """
    Save trading configuration settings.
    
    Expected JSON payload:
    {
        "riskPerTrade": 2.0,
        "maxOpenPositions": 5,
        "defaultLeverage": 1,
        "enableLiveTrading": false
    }
    """
    try:
        # Get request data
        data = request.json
        if not data:
            return jsonify({'error': 'No data provided'}), 400
        
        # Validate required fields
        required_fields = ['riskPerTrade', 'maxOpenPositions', 'defaultLeverage', 'enableLiveTrading']
        for field in required_fields:
            if field not in data:
                return jsonify({'error': f'Missing required field: {field}'}), 400
        
        # Create data directory if it doesn't exist
        data_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), 'data')
        os.makedirs(data_dir, exist_ok=True)
        
        # Save trading config
        config_path = os.path.join(data_dir, 'trading_config.json')
        
        # Add timestamp
        data['timestamp'] = datetime.now().isoformat()
        
        with open(config_path, 'w') as f:
            logger.info(f"Saving trading config: {data}")
            json.dump(data, f, indent=2)
        
        return jsonify({'success': True, 'message': 'Trading configuration saved successfully'})
    except Exception as e:
        logger.error(f"Error saving trading config: {str(e)}")
        logger.error(traceback.format_exc())
        return jsonify({'error': str(e)}), 500

@config_bp.route('/api', methods=['GET'])
def get_api_config():
    """Get the current API configuration."""
    try:
        config_path = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), 'data', 'api_config.json')
        
        if not os.path.exists(config_path):
            return jsonify({
                'exchange': 'binance',
                'apiKey': '',
                'apiSecret': '',
                'testnet': True
            })
        
        with open(config_path, 'r') as f:
            config = json.load(f)
            
            # Mask API secret
            if 'apiSecret' in config:
                config['apiSecret'] = '***********'
            
            return jsonify(config)
    except Exception as e:
        logger.error(f"Error getting API config: {str(e)}")
        logger.error(traceback.format_exc())
        return jsonify({'error': str(e)}), 500

@config_bp.route('/trading', methods=['GET'])
def get_trading_config():
    """Get the current trading configuration."""
    try:
        config_path = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), 'data', 'trading_config.json')
        
        if not os.path.exists(config_path):
            return jsonify({
                'riskPerTrade': 2.0,
                'maxOpenPositions': 5,
                'defaultLeverage': 1,
                'enableLiveTrading': False
            })
        
        with open(config_path, 'r') as f:
            config = json.load(f)
            return jsonify(config)
    except Exception as e:
        logger.error(f"Error getting trading config: {str(e)}")
        logger.error(traceback.format_exc())
        return jsonify({'error': str(e)}), 500
