"""
Backtest API routes for the Flask application.
This file contains the backtest blueprint and endpoints for running backtests.
"""

from flask import Blueprint, jsonify, request
import logging
import os
import json
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
import sys
import traceback

# Import bot modules from local models directory
from src.models.strategy_manual import EMACrossoverStrategy, RSIStrategy, MACDStrategy, BollingerBandsStrategy
from src.models.data_structures import BacktestConfig, TimeFrame, MarketType

# Create blueprint
backtest_bp = Blueprint('backtest', __name__)

# Set up logging
logger = logging.getLogger(__name__)

@backtest_bp.route('/', methods=['POST'])
def run_backtest():
    """
    Run a backtest with the provided configuration.
    
    Expected JSON payload:
    {
        "strategy": "ema_crossover",
        "symbol": "BTC/USDT",
        "timeframe": "1d",
        "startDate": "2024-01-01",
        "endDate": "2024-12-31",
        "initialCapital": 10000,
        "marketType": "spot",
        "leverage": 1,
        "commissionRate": 0.001
    }
    """
    try:
        # Get request data
        data = request.json
        if not data:
            return jsonify({'error': 'No data provided'}), 400
        
        # Validate required fields
        required_fields = ['strategy', 'symbol', 'timeframe', 'startDate', 'endDate', 'initialCapital', 'marketType']
        for field in required_fields:
            if field not in data:
                return jsonify({'error': f'Missing required field: {field}'}), 400
        
        # Parse dates
        try:
            start_date = datetime.strptime(data['startDate'], '%Y-%m-%d')
            end_date = datetime.strptime(data['endDate'], '%Y-%m-%d')
        except ValueError:
            return jsonify({'error': 'Invalid date format. Use YYYY-MM-DD'}), 400
        
        # Create backtest config
        config = BacktestConfig(
            start_date=start_date,
            end_date=end_date,
            initial_capital=float(data['initialCapital']),
            symbols=[data['symbol']],
            timeframe=parse_timeframe(data['timeframe']),
            strategy_name=data['strategy'],
            market_type=MarketType.SPOT if data['marketType'] == 'spot' else MarketType.FUTURES,
            leverage=int(data.get('leverage', 1)),
            commission_rate=float(data.get('commissionRate', 0.001))
        )
        
        # Import the backtesting engine
        from src.models.backtest_manual import BacktestingEngine
        
        # Create backtesting engine
        engine = BacktestingEngine(config)
        
        # Generate sample data
        engine.generate_sample_data(data['symbol'], days=365)
        
        # Create strategy
        strategy = create_strategy(data['strategy'])
        
        # Run backtest
        result = engine.run_backtest(strategy)
        
        # Generate plots
        equity_curve_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'static', 'img', 'equity_curve.png')
        trades_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'static', 'img', 'trades.png')
        
        engine.plot_equity_curve(save_path=equity_curve_path)
        engine.plot_trades(data['symbol'], save_path=trades_path)
        
        # Generate report
        report_path = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), 'data', 'backtest_report.md')
        report = engine.generate_report(save_path=report_path)
        
        # Prepare response
        response = {
            'success': True,
            'config': {
                'strategy': data['strategy'],
                'symbol': data['symbol'],
                'timeframe': data['timeframe'],
                'startDate': data['startDate'],
                'endDate': data['endDate'],
                'initialCapital': float(data['initialCapital']),
                'marketType': data['marketType'],
                'leverage': int(data.get('leverage', 1)),
                'commissionRate': float(data.get('commissionRate', 0.001))
            },
            'results': {
                'initialCapital': config.initial_capital,
                'finalCapital': result.equity_curve[-1] if result.equity_curve else config.initial_capital,
                'totalPnl': result.total_pnl,
                'totalPnlPercentage': result.total_pnl_percentage,
                'winCount': result.win_count,
                'lossCount': result.loss_count,
                'winRate': result.win_rate,
                'maxDrawdown': result.max_drawdown,
                'maxDrawdownPercentage': result.max_drawdown_percentage,
                'sharpeRatio': result.sharpe_ratio,
                'sortinoRatio': result.sortino_ratio,
                'profitFactor': result.profit_factor
            },
            'trades': format_trades(result.trades),
            'equityCurve': result.equity_curve,
            'timestamps': [datetime.fromtimestamp(ts/1000).strftime('%Y-%m-%d') for ts in result.timestamps],
            'images': {
                'equityCurve': '/static/img/equity_curve.png',
                'trades': '/static/img/trades.png'
            }
        }
        
        # Save the backtest result for later reference
        save_backtest_result(response)
        
        return jsonify(response)
    except Exception as e:
        logger.error(f"Error running backtest: {str(e)}")
        logger.error(traceback.format_exc())
        return jsonify({'error': str(e)}), 500

def parse_timeframe(timeframe_str):
    """Parse timeframe string to TimeFrame enum."""
    timeframe_map = {
        '1m': TimeFrame.MINUTE_1,
        '5m': TimeFrame.MINUTE_5,
        '15m': TimeFrame.MINUTE_15,
        '1h': TimeFrame.HOUR_1,
        '4h': TimeFrame.HOUR_4,
        '1d': TimeFrame.DAY_1
    }
    return timeframe_map.get(timeframe_str, TimeFrame.DAY_1)

def create_strategy(strategy_name):
    """Create strategy object based on strategy name."""
    strategy_map = {
        'ema_crossover': EMACrossoverStrategy(fast_period=12, slow_period=26),
        'rsi': RSIStrategy(rsi_period=14, overbought=70, oversold=30),
        'macd': MACDStrategy(fast_period=12, slow_period=26, signal_period=9),
        'bollinger_bands': BollingerBandsStrategy(period=20, std_dev=2)
    }
    return strategy_map.get(strategy_name, EMACrossoverStrategy(fast_period=12, slow_period=26))

def format_trades(trades):
    """Format trades for JSON response."""
    formatted_trades = []
    for trade in trades:
        formatted_trades.append({
            'symbol': trade.symbol,
            'entryTime': trade.entry_order.timestamp,
            'exitTime': trade.exit_order.timestamp if trade.exit_order else None,
            'entryPrice': trade.entry_order.average_fill_price,
            'exitPrice': trade.exit_order.average_fill_price if trade.exit_order else None,
            'quantity': trade.entry_order.filled_quantity,
            'pnl': trade.pnl,
            'pnlPercentage': trade.pnl_percentage,
            'duration': trade.duration
        })
    return formatted_trades

def save_backtest_result(result):
    """Save backtest result to file for later reference."""
    data_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), 'data')
    os.makedirs(data_dir, exist_ok=True)
    
    result_path = os.path.join(data_dir, 'latest_backtest.json')
    
    with open(result_path, 'w') as f:
        json.dump(result, f, indent=2)
    
    logger.info(f"Backtest result saved to {result_path}")
