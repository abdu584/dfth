// Main JavaScript for Crypto Trading Bot Web Application

document.addEventListener('DOMContentLoaded', function() {
    // Navigation
    const navLinks = document.querySelectorAll('.nav-links a');
    const sections = document.querySelectorAll('.section');
    
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const targetSection = this.getAttribute('data-section');
            
            // Update active link
            navLinks.forEach(link => link.classList.remove('active'));
            this.classList.add('active');
            
            // Show target section, hide others
            sections.forEach(section => {
                if (section.id === targetSection) {
                    section.classList.add('active');
                } else {
                    section.classList.remove('active');
                }
            });
        });
    });
    
    // Tab functionality
    const tabs = document.querySelectorAll('.tab');
    
    tabs.forEach(tab => {
        tab.addEventListener('click', function() {
            const tabContainer = this.closest('.tabs');
            const tabContents = tabContainer.nextElementSibling.parentElement.querySelectorAll('.tab-content');
            const targetTab = this.getAttribute('data-tab');
            
            // Update active tab
            tabContainer.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
            this.classList.add('active');
            
            // Show target tab content, hide others
            tabContents.forEach(content => {
                if (content.id === targetTab) {
                    content.classList.add('active');
                } else {
                    content.classList.remove('active');
                }
            });
        });
    });
    
    // Toggle switches
    const toggleSwitches = document.querySelectorAll('input[type="checkbox"]');
    
    toggleSwitches.forEach(toggle => {
        toggle.addEventListener('change', function() {
            const label = this.parentElement.nextElementSibling;
            if (this.checked) {
                label.textContent = 'Yes';
            } else {
                label.textContent = 'No';
            }
        });
    });
    
    // Market type change (show/hide leverage)
    const marketTypeSelect = document.getElementById('marketType');
    const leverageGroup = document.getElementById('leverageGroup');
    
    if (marketTypeSelect && leverageGroup) {
        marketTypeSelect.addEventListener('change', function() {
            if (this.value === 'futures') {
                leverageGroup.style.display = 'block';
            } else {
                leverageGroup.style.display = 'none';
            }
        });
    }
    
    // Set default dates for backtest form
    const startDateInput = document.getElementById('startDate');
    const endDateInput = document.getElementById('endDate');
    
    if (startDateInput && endDateInput) {
        const today = new Date();
        const oneYearAgo = new Date();
        oneYearAgo.setFullYear(today.getFullYear() - 1);
        
        startDateInput.valueAsDate = oneYearAgo;
        endDateInput.valueAsDate = today;
    }
    
    // Backtest form submission
    const backtestForm = document.getElementById('backtestForm');
    
    if (backtestForm) {
        backtestForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Show loading state
            document.getElementById('backtestEmpty').classList.add('hidden');
            document.getElementById('backtestResults').classList.add('hidden');
            document.getElementById('backtestLoading').classList.remove('hidden');
            
            // Collect form data
            const formData = new FormData(this);
            const backtestConfig = Object.fromEntries(formData.entries());
            
            // Convert commission rate from percentage to decimal
            backtestConfig.commissionRate = parseFloat(backtestConfig.commissionRate) / 100;
            
            // Send API request
            fetch('/api/backtest', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(backtestConfig)
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error('Backtest failed');
                }
                return response.json();
            })
            .then(data => {
                // Hide loading state
                document.getElementById('backtestLoading').classList.add('hidden');
                document.getElementById('backtestResults').classList.remove('hidden');
                
                // Display results
                displayBacktestResults(data);
            })
            .catch(error => {
                console.error('Error:', error);
                document.getElementById('backtestLoading').classList.add('hidden');
                document.getElementById('backtestEmpty').classList.remove('hidden');
                alert('Failed to run backtest. Please try again.');
            });
        });
    }
    
    // Predictions form submission
    const predictionsForm = document.getElementById('predictionsForm');
    
    if (predictionsForm) {
        predictionsForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Show loading state
            document.getElementById('predictionsEmpty').classList.add('hidden');
            document.getElementById('predictionsResults').classList.add('hidden');
            document.getElementById('predictionsLoading').classList.remove('hidden');
            
            // Collect form data
            const formData = new FormData(this);
            const predictionConfig = Object.fromEntries(formData.entries());
            
            // Convert symbols to array
            predictionConfig.symbols = predictionConfig.predictionSymbols.split(',').map(s => s.trim());
            delete predictionConfig.predictionSymbols;
            
            // Send API request
            fetch('/api/predict', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(predictionConfig)
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error('Prediction failed');
                }
                return response.json();
            })
            .then(data => {
                // Hide loading state
                document.getElementById('predictionsLoading').classList.add('hidden');
                document.getElementById('predictionsResults').classList.remove('hidden');
                
                // Display results
                displayPredictionResults(data);
            })
            .catch(error => {
                console.error('Error:', error);
                document.getElementById('predictionsLoading').classList.add('hidden');
                document.getElementById('predictionsEmpty').classList.remove('hidden');
                alert('Failed to generate predictions. Please try again.');
            });
        });
    }
    
    // API Config form submission
    const apiConfigForm = document.getElementById('apiConfigForm');
    
    if (apiConfigForm) {
        apiConfigForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Collect form data
            const formData = new FormData(this);
            const apiConfig = Object.fromEntries(formData.entries());
            
            // Convert checkbox value
            apiConfig.testnet = apiConfig.testnet === 'on';
            
            // Send API request
            fetch('/api/config/api', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(apiConfig)
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error('Failed to save API configuration');
                }
                return response.json();
            })
            .then(data => {
                alert('API configuration saved successfully');
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Failed to save API configuration. Please try again.');
            });
        });
    }
    
    // Trading Settings form submission
    const tradingSettingsForm = document.getElementById('tradingSettingsForm');
    
    if (tradingSettingsForm) {
        tradingSettingsForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Collect form data
            const formData = new FormData(this);
            const tradingSettings = Object.fromEntries(formData.entries());
            
            // Convert checkbox value
            tradingSettings.enableLiveTrading = tradingSettings.enableLiveTrading === 'on';
            
            // Send API request
            fetch('/api/config/trading', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(tradingSettings)
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error('Failed to save trading settings');
                }
                return response.json();
            })
            .then(data => {
                alert('Trading settings saved successfully');
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Failed to save trading settings. Please try again.');
            });
        });
    }
    
    // Load initial dashboard data
    loadDashboardData();
    
    // Helper functions
    function loadDashboardData() {
        // Fetch dashboard data from API
        fetch('/api/dashboard')
            .then(response => {
                if (!response.ok) {
                    return { equity: [], trades: [], metrics: {}, predictions: { bullish: [], bearish: [] } };
                }
                return response.json();
            })
            .then(data => {
                // Update dashboard with data
                updateDashboardCharts(data);
                updateDashboardTables(data);
                updateDashboardMetrics(data);
            })
            .catch(error => {
                console.error('Error loading dashboard data:', error);
            });
    }
    
    function updateDashboardCharts(data) {
        // Equity chart
        const equityCtx = document.getElementById('equityChart').getContext('2d');
        
        // Sample data if no real data available
        const equityData = data.equity && data.equity.length > 0 ? data.equity : generateSampleEquityData();
        
        new Chart(equityCtx, {
            type: 'line',
            data: {
                labels: equityData.map(d => d.date),
                datasets: [{
                    label: 'Equity Curve',
                    data: equityData.map(d => d.value),
                    borderColor: '#2563eb',
                    backgroundColor: 'rgba(37, 99, 235, 0.1)',
                    fill: true,
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: true,
                        position: 'top'
                    },
                    tooltip: {
                        mode: 'index',
                        intersect: false
                    }
                },
                scales: {
                    x: {
                        grid: {
                            display: false
                        }
                    },
                    y: {
                        beginAtZero: false,
                        grid: {
                            color: 'rgba(0, 0, 0, 0.05)'
                        }
                    }
                }
            }
        });
    }
    
    function updateDashboardTables(data) {
        // Recent trades table
        const recentTradesTable = document.getElementById('recentTradesTable');
        
        if (data.trades && data.trades.length > 0) {
            recentTradesTable.innerHTML = '';
            
            data.trades.forEach(trade => {
                const row = document.createElement('tr');
                
                const pnlClass = trade.pnl >= 0 ? 'text-green-600' : 'text-red-600';
                
                row.innerHTML = `
                    <td>${trade.symbol}</td>
                    <td>${trade.side}</td>
                    <td>$${trade.entryPrice.toFixed(2)}</td>
                    <td>$${trade.exitPrice.toFixed(2)}</td>
                    <td class="${pnlClass}">$${trade.pnl.toFixed(2)} (${trade.pnlPercentage.toFixed(2)}%)</td>
                `;
                
                recentTradesTable.appendChild(row);
            });
        }
        
        // Prediction tables
        const bullishPredictionsTable = document.getElementById('bullishPredictionsTable');
        const bearishPredictionsTable = document.getElementById('bearishPredictionsTable');
        
        if (data.predictions) {
            // Bullish predictions
            if (data.predictions.bullish && data.predictions.bullish.length > 0) {
                bullishPredictionsTable.innerHTML = '';
                
                data.predictions.bullish.forEach(pred => {
                    const row = document.createElement('tr');
                    
                    row.innerHTML = `
                        <td>${pred.symbol}</td>
                        <td>${(pred.confidence * 100).toFixed(1)}%</td>
                        <td>${pred.indicators || 'N/A'}</td>
                    `;
                    
                    bullishPredictionsTable.appendChild(row);
                });
            }
            
            // Bearish predictions
            if (data.predictions.bearish && data.predictions.bearish.length > 0) {
                bearishPredictionsTable.innerHTML = '';
                
                data.predictions.bearish.forEach(pred => {
                    const row = document.createElement('tr');
                    
                    row.innerHTML = `
                        <td>${pred.symbol}</td>
                        <td>${(pred.confidence * 100).toFixed(1)}%</td>
                        <td>${pred.indicators || 'N/A'}</td>
                    `;
                    
                    bearishPredictionsTable.appendChild(row);
                });
            }
        }
    }
    
    function updateDashboardMetrics(data) {
        // Update metrics
        if (data.metrics) {
            document.getElementById('totalPnl').textContent = `$${data.metrics.totalPnl ? data.metrics.totalPnl.toFixed(2) : '0.00'}`;
            document.getElementById('winRate').textContent = `${data.metrics.winRate ? (data.metrics.winRate * 100).toFixed(1) : '0'}%`;
            document.getElementById('sharpeRatio').textContent = data.metrics.sharpeRatio ? data.metrics.sharpeRatio.toFixed(2) : '0.00';
            document.getElementById('maxDrawdown').textContent = `${data.metrics.maxDrawdown ? (data.metrics.maxDrawdown * 100).toFixed(2) : '0'}%`;
        }
    }
    
    function displayBacktestResults(data) {
        // Display equity curve
        const equityCtx = document.getElementById('backtestEquityChart').getContext('2d');
        
        new Chart(equityCtx, {
            type: 'line',
            data: {
                labels: data.timestamps.map(ts => new Date(ts).toLocaleDateString()),
                datasets: [{
                    label: 'Equity Curve',
                    data: data.equityCurve,
                    borderColor: '#2563eb',
                    backgroundColor: 'rgba(37, 99, 235, 0.1)',
                    fill: true,
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: true,
                        position: 'top'
                    },
                    tooltip: {
                        mode: 'index',
                        intersect: false
                    }
                },
                scales: {
                    x: {
                        grid: {
                            display: false
                        }
                    },
                    y: {
                        beginAtZero: false,
                        grid: {
                            color: 'rgba(0, 0, 0, 0.05)'
                        }
                    }
                }
            }
        });
        
        // Display drawdown chart
        const drawdownCtx = document.getElementById('backtestDrawdownChart').getContext('2d');
        
        new Chart(drawdownCtx, {
            type: 'line',
            data: {
                labels: data.timestamps.map(ts => new Date(ts).toLocaleDateString()),
                datasets: [{
                    label: 'Drawdown %',
                    data: data.drawdowns || calculateDrawdowns(data.equityCurve),
                    borderColor: '#ef4444',
                    backgroundColor: 'rgba(239, 68, 68, 0.1)',
                    fill: true,
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: true,
                        position: 'top'
                    },
                    tooltip: {
                        mode: 'index',
                        intersect: false
                    }
                },
                scales: {
                    x: {
                        grid: {
                            display: false
                        }
                    },
                    y: {
                        beginAtZero: true,
                        reverse: true,
                        grid: {
                            color: 'rgba(0, 0, 0, 0.05)'
                        }
                    }
                }
            }
        });
        
        // Display trades table
        const tradesTable = document.getElementById('backtestTradesTable');
        tradesTable.innerHTML = '';
        
        if (data.trades && data.trades.length > 0) {
            data.trades.forEach(trade => {
                const row = document.createElement('tr');
                
                const pnlClass = trade.pnl >= 0 ? 'text-green-600' : 'text-red-600';
                
                row.innerHTML = `
                    <td>${trade.symbol}</td>
                    <td>${new Date(trade.entryTime).toLocaleString()}</td>
                    <td>${new Date(trade.exitTime).toLocaleString()}</td>
                    <td>$${trade.entryPrice.toFixed(2)}</td>
                    <td>$${trade.exitPrice.toFixed(2)}</td>
                    <td class="${pnlClass}">$${trade.pnl.toFixed(2)}</td>
                    <td class="${pnlClass}">${trade.pnlPercentage.toFixed(2)}%</td>
                `;
                
                tradesTable.appendChild(row);
            });
        } else {
            tradesTable.innerHTML = '<tr><td colspan="7" class="text-center">No trades executed</td></tr>';
        }
        
        // Display metrics
        document.getElementById('metricsInitialCapital').textContent = `$${data.initialCapital.toFixed(2)}`;
        document.getElementById('metricsFinalCapital').textContent = `$${data.finalCapital.toFixed(2)}`;
        document.getElementById('metricsTotalPnl').textContent = `$${data.totalPnl.toFixed(2)} (${data.totalPnlPercentage.toFixed(2)}%)`;
        document.getElementById('metricsWinRate').textContent = `${(data.winRate * 100).toFixed(2)}% (${data.winCount}/${data.winCount + data.lossCount})`;
        document.getElementById('metricsMaxDrawdown').textContent = `${data.maxDrawdownPercentage.toFixed(2)}%`;
        document.getElementById('metricsSharpeRatio').textContent = data.sharpeRatio.toFixed(2);
        document.getElementById('metricsSortinoRatio').textContent = data.sortinoRatio.toFixed(2);
        document.getElementById('metricsProfitFactor').textContent = data.profitFactor.toFixed(2);
        
        document.getElementById('metricsTotalTrades').textContent = data.trades ? data.trades.length : 0;
        document.getElementById('metricsWinningTrades').textContent = data.winCount;
        document.getElementById('metricsLosingTrades').textContent = data.lossCount;
        
        if (data.trades && data.trades.length > 0) {
            const avgPnl = data.totalPnl / data.trades.length;
            const avgPnlPercent = data.trades.reduce((sum, trade) => sum + trade.pnlPercentage, 0) / data.trades.length;
            const avgDuration = data.trades.reduce((sum, trade) => sum + (trade.exitTime - trade.entryTime), 0) / data.trades.length / (1000 * 60); // Convert to minutes
            
            document.getElementById('metricsAvgPnl').textContent = `$${avgPnl.toFixed(2)}`;
            document.getElementById('metricsAvgPnlPercent').textContent = `${avgPnlPercent.toFixed(2)}%`;
            document.getElementById('metricsAvgDuration').textContent = `${avgDuration.toFixed(2)} minutes`;
        }
    }
    
    function displayPredictionResults(data) {
        // Display predictions chart
        const predictionsCtx = document.getElementById('predictionsChart').getContext('2d');
        
        const symbols = [];
        const confidences = [];
        const colors = [];
        
        // Add bullish predictions
        if (data.bullish && data.bullish.length > 0) {
            data.bullish.forEach(pred => {
                symbols.push(pred.symbol);
                confidences.push(pred.confidence);
                colors.push('#10b981'); // Green for bullish
            });
        }
        
        // Add bearish predictions
        if (data.bearish && data.bearish.length > 0) {
            data.bearish.forEach(pred => {
                symbols.push(pred.symbol);
                confidences.push(pred.confidence);
                colors.push('#ef4444'); // Red for bearish
            });
        }
        
        new Chart(predictionsCtx, {
            type: 'bar',
            data: {
                labels: symbols,
                datasets: [{
                    label: 'Confidence Score',
                    data: confidences,
                    backgroundColor: colors,
                    borderColor: colors,
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    x: {
                        grid: {
                            display: false
                        }
                    },
                    y: {
                        beginAtZero: true,
                        max: 1,
                        grid: {
                            color: 'rgba(0, 0, 0, 0.05)'
                        }
                    }
                }
            }
        });
        
        // Display bullish predictions table
        const bullishTable = document.getElementById('bullishPredictionsResultTable');
        bullishTable.innerHTML = '';
        
        if (data.bullish && data.bullish.length > 0) {
            data.bullish.forEach(pred => {
                const row = document.createElement('tr');
                
                row.innerHTML = `
                    <td>${pred.symbol}</td>
                    <td>${(pred.confidence * 100).toFixed(1)}%</td>
                    <td>${pred.features && pred.features.rsi_14 ? pred.features.rsi_14.toFixed(2) : 'N/A'}</td>
                    <td>${pred.features && pred.features.macd ? pred.features.macd.toFixed(2) : 'N/A'}</td>
                    <td>${pred.features && pred.features.bb_position ? pred.features.bb_position.toFixed(2) : 'N/A'}</td>
                `;
                
                bullishTable.appendChild(row);
            });
        } else {
            bullishTable.innerHTML = '<tr><td colspan="5" class="text-center">No bullish predictions found</td></tr>';
        }
        
        // Display bearish predictions table
        const bearishTable = document.getElementById('bearishPredictionsResultTable');
        bearishTable.innerHTML = '';
        
        if (data.bearish && data.bearish.length > 0) {
            data.bearish.forEach(pred => {
                const row = document.createElement('tr');
                
                row.innerHTML = `
                    <td>${pred.symbol}</td>
                    <td>${(pred.confidence * 100).toFixed(1)}%</td>
                    <td>${pred.features && pred.features.rsi_14 ? pred.features.rsi_14.toFixed(2) : 'N/A'}</td>
                    <td>${pred.features && pred.features.macd ? pred.features.macd.toFixed(2) : 'N/A'}</td>
                    <td>${pred.features && pred.features.bb_position ? pred.features.bb_position.toFixed(2) : 'N/A'}</td>
                `;
                
                bearishTable.appendChild(row);
            });
        } else {
            bearishTable.innerHTML = '<tr><td colspan="5" class="text-center">No bearish predictions found</td></tr>';
        }
    }
    
    function calculateDrawdowns(equityCurve) {
        if (!equityCurve || equityCurve.length === 0) {
            return [];
        }
        
        const drawdowns = [];
        let peak = equityCurve[0];
        
        for (let i = 0; i < equityCurve.length; i++) {
            if (equityCurve[i] > peak) {
                peak = equityCurve[i];
            }
            
            const drawdown = (peak - equityCurve[i]) / peak * 100;
            drawdowns.push(drawdown);
        }
        
        return drawdowns;
    }
    
    function generateSampleEquityData() {
        const data = [];
        const today = new Date();
        let equity = 10000;
        
        for (let i = 30; i >= 0; i--) {
            const date = new Date();
            date.setDate(today.getDate() - i);
            
            // Random daily return between -2% and +2%
            const dailyReturn = (Math.random() * 4 - 2) / 100;
            equity = equity * (1 + dailyReturn);
            
            data.push({
                date: date.toLocaleDateString(),
                value: equity
            });
        }
        
        return data;
    }
});
