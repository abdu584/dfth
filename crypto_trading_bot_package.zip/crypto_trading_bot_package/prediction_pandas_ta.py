"""
Prediction Engine Implementation for Crypto Trading Bot (using pandas-ta instead of TA-Lib).

This module implements the prediction engine functionality:
- Classifying coins into "rising" or "falling" categories
- Using technical indicators for predictions
- Generating confidence scores for predictions
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from typing import Dict, List, Optional, Union, Tuple, Any
import datetime
import logging
import os
import json
import pandas_ta as ta
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, precision_score, recall_score
import joblib

from data_structures import (
    OHLCV, Prediction, PredictionDirection, TimeFrame
)


class PredictionEngine:
    """Engine for predicting price movements of cryptocurrencies."""
    
    def __init__(self, prediction_window: int = 7, confidence_threshold: float = 0.7):
        """
        Initialize the prediction engine.
        
        Args:
            prediction_window: Number of days to look ahead for predictions
            confidence_threshold: Threshold for prediction confidence
        """
        self.prediction_window = prediction_window
        self.confidence_threshold = confidence_threshold
        self.models = {}
        self.scalers = {}
        self.logger = logging.getLogger(__name__)
    
    def generate_features(self, ohlcv_df: pd.DataFrame) -> pd.DataFrame:
        """
        Generate technical features from OHLCV data.
        
        Args:
            ohlcv_df: DataFrame with OHLCV data
            
        Returns:
            DataFrame with technical indicators as features
        """
        df = ohlcv_df.copy()
        
        # Price-based features
        df['returns'] = df['close'].pct_change()
        df['log_returns'] = np.log(df['close'] / df['close'].shift(1))
        
        # Moving averages
        df['sma_5'] = df.ta.sma(length=5)
        df['sma_10'] = df.ta.sma(length=10)
        df['sma_20'] = df.ta.sma(length=20)
        df['sma_50'] = df.ta.sma(length=50)
        
        # Exponential moving averages
        df['ema_5'] = df.ta.ema(length=5)
        df['ema_10'] = df.ta.ema(length=10)
        df['ema_20'] = df.ta.ema(length=20)
        df['ema_50'] = df.ta.ema(length=50)
        
        # Moving average crossovers
        df['ema_5_10_cross'] = df['ema_5'] - df['ema_10']
        df['ema_10_20_cross'] = df['ema_10'] - df['ema_20']
        df['ema_20_50_cross'] = df['ema_20'] - df['ema_50']
        
        # Momentum indicators
        df['rsi_14'] = df.ta.rsi(length=14)
        df['rsi_7'] = df.ta.rsi(length=7)
        
        # MACD
        macd = df.ta.macd(fast=12, slow=26, signal=9)
        df['macd'] = macd[f'MACD_12_26_9']
        df['macd_signal'] = macd[f'MACDs_12_26_9']
        df['macd_hist'] = macd[f'MACDh_12_26_9']
        
        # Bollinger Bands
        bbands = df.ta.bbands(length=20, std=2)
        df['bb_upper'] = bbands[f'BBU_20_2.0']
        df['bb_middle'] = bbands[f'BBM_20_2.0']
        df['bb_lower'] = bbands[f'BBL_20_2.0']
        df['bb_width'] = (df['bb_upper'] - df['bb_lower']) / df['bb_middle']
        df['bb_position'] = (df['close'] - df['bb_lower']) / (df['bb_upper'] - df['bb_lower'])
        
        # Stochastic Oscillator
        stoch = df.ta.stoch(k=14, d=3, smooth_k=3)
        df['stoch_k'] = stoch[f'STOCHk_14_3_3']
        df['stoch_d'] = stoch[f'STOCHd_14_3_3']
        
        # Average Directional Index
        adx = df.ta.adx(length=14)
        df['adx'] = adx[f'ADX_14']
        
        # Commodity Channel Index
        df['cci'] = df.ta.cci(length=14)
        
        # Average True Range
        df['atr'] = df.ta.atr(length=14)
        
        # On-Balance Volume
        df['obv'] = df.ta.obv()
        
        # Price relative to moving averages
        df['close_sma_5_ratio'] = df['close'] / df['sma_5']
        df['close_sma_10_ratio'] = df['close'] / df['sma_10']
        df['close_sma_20_ratio'] = df['close'] / df['sma_20']
        
        # Volatility
        df['volatility_5'] = df['returns'].rolling(5).std()
        df['volatility_10'] = df['returns'].rolling(10).std()
        df['volatility_20'] = df['returns'].rolling(20).std()
        
        # Drop NaN values
        df = df.dropna()
        
        return df
    
    def prepare_training_data(self, ohlcv_df: pd.DataFrame) -> Tuple[pd.DataFrame, pd.Series]:
        """
        Prepare training data for ML model.
        
        Args:
            ohlcv_df: DataFrame with OHLCV data
            
        Returns:
            Tuple of (X, y) where X is features and y is target labels
        """
        # Generate features
        df = self.generate_features(ohlcv_df)
        
        # Create target variable (1 for price increase after prediction_window, 0 for decrease)
        df['future_price'] = df['close'].shift(-self.prediction_window)
        df['target'] = (df['future_price'] > df['close']).astype(int)
        
        # Drop rows with NaN in target
        df = df.dropna()
        
        # Select features
        feature_columns = [
            'returns', 'log_returns', 
            'sma_5', 'sma_10', 'sma_20', 'sma_50',
            'ema_5', 'ema_10', 'ema_20', 'ema_50',
            'ema_5_10_cross', 'ema_10_20_cross', 'ema_20_50_cross',
            'rsi_14', 'rsi_7',
            'macd', 'macd_signal', 'macd_hist',
            'bb_width', 'bb_position',
            'stoch_k', 'stoch_d',
            'adx', 'cci', 'atr',
            'close_sma_5_ratio', 'close_sma_10_ratio', 'close_sma_20_ratio',
            'volatility_5', 'volatility_10', 'volatility_20'
        ]
        
        X = df[feature_columns]
        y = df['target']
        
        return X, y
    
    def train_model(self, symbol: str, ohlcv_df: pd.DataFrame) -> float:
        """
        Train prediction model for a symbol.
        
        Args:
            symbol: Trading pair symbol
            ohlcv_df: DataFrame with OHLCV data
            
        Returns:
            Model accuracy score
        """
        # Prepare data
        X, y = self.prepare_training_data(ohlcv_df)
        
        if len(X) < 100:
            self.logger.warning(f"Not enough data to train model for {symbol}")
            return 0.0
        
        # Split data
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
        
        # Scale features
        scaler = StandardScaler()
        X_train_scaled = scaler.fit_transform(X_train)
        X_test_scaled = scaler.transform(X_test)
        
        # Train model
        model = RandomForestClassifier(
            n_estimators=100, 
            max_depth=10, 
            random_state=42
        )
        model.fit(X_train_scaled, y_train)
        
        # Evaluate model
        y_pred = model.predict(X_test_scaled)
        accuracy = accuracy_score(y_test, y_pred)
        
        # Store model and scaler
        self.models[symbol] = model
        self.scalers[symbol] = scaler
        
        self.logger.info(f"Trained model for {symbol} with accuracy: {accuracy:.4f}")
        
        return accuracy
    
    def predict(self, symbol: str, ohlcv_df: pd.DataFrame) -> Prediction:
        """
        Generate prediction for a symbol.
        
        Args:
            symbol: Trading pair symbol
            ohlcv_df: DataFrame with OHLCV data
            
        Returns:
            Prediction object with direction and confidence
        """
        # Check if we have a trained model
        if symbol not in self.models:
            # Use technical indicators for prediction
            return self._predict_with_indicators(symbol, ohlcv_df)
        
        # Generate features
        df = self.generate_features(ohlcv_df)
        
        # Get latest data point
        latest_data = df.iloc[-1:]
        
        # Select features
        feature_columns = [
            'returns', 'log_returns', 
            'sma_5', 'sma_10', 'sma_20', 'sma_50',
            'ema_5', 'ema_10', 'ema_20', 'ema_50',
            'ema_5_10_cross', 'ema_10_20_cross', 'ema_20_50_cross',
            'rsi_14', 'rsi_7',
            'macd', 'macd_signal', 'macd_hist',
            'bb_width', 'bb_position',
            'stoch_k', 'stoch_d',
            'adx', 'cci', 'atr',
            'close_sma_5_ratio', 'close_sma_10_ratio', 'close_sma_20_ratio',
            'volatility_5', 'volatility_10', 'volatility_20'
        ]
        
        X = latest_data[feature_columns]
        
        # Scale features
        X_scaled = self.scalers[symbol].transform(X)
        
        # Predict
        probabilities = self.models[symbol].predict_proba(X_scaled)[0]
        prediction_class = self.models[symbol].predict(X_scaled)[0]
        
        # Get confidence
        confidence = probabilities[prediction_class]
        
        # Create prediction
        direction = PredictionDirection.BULLISH if prediction_class == 1 else PredictionDirection.BEARISH
        
        prediction = Prediction(
            symbol=symbol,
            direction=direction,
            confidence=confidence,
            timestamp=int(datetime.datetime.now().timestamp() * 1000),
            features={col: float(X[col].iloc[0]) for col in X.columns},
            model_name="RandomForest"
        )
        
        return prediction
    
    def _predict_with_indicators(self, symbol: str, ohlcv_df: pd.DataFrame) -> Prediction:
        """
        Generate prediction using technical indicators.
        
        Args:
            symbol: Trading pair symbol
            ohlcv_df: DataFrame with OHLCV data
            
        Returns:
            Prediction object with direction and confidence
        """
        # Generate features
        df = self.generate_features(ohlcv_df)
        
        # Get latest data point
        latest = df.iloc[-1]
        
        # Calculate signals
        signals = []
        confidences = []
        
        # EMA crossovers
        if latest['ema_5'] > latest['ema_10']:
            signals.append(1)
            confidences.append(0.6)
        else:
            signals.append(-1)
            confidences.append(0.6)
            
        if latest['ema_10'] > latest['ema_20']:
            signals.append(1)
            confidences.append(0.65)
        else:
            signals.append(-1)
            confidences.append(0.65)
            
        if latest['ema_20'] > latest['ema_50']:
            signals.append(1)
            confidences.append(0.7)
        else:
            signals.append(-1)
            confidences.append(0.7)
        
        # RSI
        if latest['rsi_14'] < 30:
            signals.append(1)  # Oversold, likely to rise
            confidences.append(0.75)
        elif latest['rsi_14'] > 70:
            signals.append(-1)  # Overbought, likely to fall
            confidences.append(0.75)
        else:
            # Neutral RSI
            if latest['rsi_14'] < 50:
                signals.append(1)
                confidences.append(0.55)
            else:
                signals.append(-1)
                confidences.append(0.55)
        
        # MACD
        if latest['macd'] > latest['macd_signal']:
            signals.append(1)
            confidences.append(0.7)
        else:
            signals.append(-1)
            confidences.append(0.7)
        
        # Bollinger Bands
        if latest['close'] < latest['bb_lower']:
            signals.append(1)  # Below lower band, likely to rise
            confidences.append(0.8)
        elif latest['close'] > latest['bb_upper']:
            signals.append(-1)  # Above upper band, likely to fall
            confidences.append(0.8)
        else:
            # Within bands
            if latest['bb_position'] < 0.3:
                signals.append(1)
                confidences.append(0.6)
            elif latest['bb_position'] > 0.7:
                signals.append(-1)
                confidences.append(0.6)
            else:
                signals.append(0)  # Neutral
                confidences.append(0.5)
        
        # Stochastic
        if latest['stoch_k'] < 20 and latest['stoch_d'] < 20:
            signals.append(1)  # Oversold
            confidences.append(0.75)
        elif latest['stoch_k'] > 80 and latest['stoch_d'] > 80:
            signals.append(-1)  # Overbought
            confidences.append(0.75)
        else:
            if latest['stoch_k'] > latest['stoch_d']:
                signals.append(1)
                confidences.append(0.6)
            else:
                signals.append(-1)
                confidences.append(0.6)
        
        # Calculate overall signal and confidence
        valid_signals = [s for s, c in zip(signals, confidences) if s != 0]
        valid_confidences = [c for s, c in zip(signals, confidences) if s != 0]
        
        if not valid_signals:
            direction = PredictionDirection.NEUTRAL
            confidence = 0.5
        else:
            # Weighted average of signals
            weighted_signal = sum(s * c for s, c in zip(valid_signals, valid_confidences)) / sum(valid_confidences)
            
            if weighted_signal > 0.2:
                direction = PredictionDirection.BULLISH
                confidence = min(0.5 + abs(weighted_signal) * 0.5, 0.95)
            elif weighted_signal < -0.2:
                direction = PredictionDirection.BEARISH
                confidence = min(0.5 + abs(weighted_signal) * 0.5, 0.95)
            else:
                direction = PredictionDirection.NEUTRAL
                confidence = 0.5
        
        # Create prediction
        prediction = Prediction(
            symbol=symbol,
            direction=direction,
            confidence=confidence,
            timestamp=int(datetime.datetime.now().timestamp() * 1000),
            features={
                'rsi_14': latest['rsi_14'],
                'macd': latest['macd'],
                'bb_position': latest['bb_position'],
                'stoch_k': latest['stoch_k']
            },
            model_name="TechnicalIndicators"
        )
        
        return prediction
    
    def predict_multiple(self, data_dict: Dict[str, pd.DataFrame]) -> Dict[str, Prediction]:
        """
        Generate predictions for multiple symbols.
        
        Args:
            data_dict: Dictionary mapping symbols to OHLCV DataFrames
            
        Returns:
            Dictionary mapping symbols to Prediction objects
        """
        predictions = {}
        
        for symbol, ohlcv_df in data_dict.items():
            try:
                prediction = self.predict(symbol, ohlcv_df)
                predictions[symbol] = prediction
                self.logger.info(f"Generated prediction for {symbol}: {prediction.direction.value} with confidence {prediction.confidence:.4f}")
            except Exception as e:
                self.logger.error(f"Error generating prediction for {symbol}: {str(e)}")
        
        return predictions
    
    def get_top_predictions(self, predictions: Dict[str, Prediction], 
                           top_n: int = 3) -> Dict[str, List[Prediction]]:
        """
        Get top bullish and bearish predictions.
        
        Args:
            predictions: Dictionary mapping symbols to Prediction objects
            top_n: Number of top predictions to return
            
        Returns:
            Dictionary with 'bullish' and 'bearish' keys mapping to lists of Predictions
        """
        # Filter by confidence threshold
        confident_predictions = {
            symbol: pred for symbol, pred in predictions.items() 
            if pred.confidence >= self.confidence_threshold
        }
        
        # Separate bullish and bearish predictions
        bullish_predictions = [
            pred for pred in confident_predictions.values() 
            if pred.direction == PredictionDirection.BULLISH
        ]
        
        bearish_predictions = [
            pred for pred in confident_predictions.values() 
            if pred.direction == PredictionDirection.BEARISH
        ]
        
        # Sort by confidence
        bullish_predictions.sort(key=lambda x: x.confidence, reverse=True)
        bearish_predictions.sort(key=lambda x: x.confidence, reverse=True)
        
        # Get top N
        top_bullish = bullish_predictions[:top_n]
        top_bearish = bearish_predictions[:top_n]
        
        return {
            'bullish': top_bullish,
            'bearish': top_bearish
        }
    
    def save_model(self, symbol: str, path: str) -> None:
        """
        Save trained model to file.
        
        Args:
            symbol: Trading pair symbol
            path: Path to save model
        """
        if symbol not in self.models:
            self.logger.warning(f"No model for {symbol} to save")
            return
        
        # Create directory if it doesn't exist
        os.makedirs(os.path.dirname(path), exist_ok=True)
        
        # Save model and scaler
        joblib.dump(self.models[symbol], f"{path}_model.joblib")
        joblib.dump(self.scalers[symbol], f"{path}_scaler.joblib")
        
        self.logger.info(f"Saved model for {symbol} to {path}")
    
    def load_model(self, symbol: str, path: str) -> None:
        """
        Load trained model from file.
        
        Args:
            symbol: Trading pair symbol
            path: Path to load model from
        """
        # Load model and scaler
        self.models[symbol] = joblib.load(f"{path}_model.joblib")
        self.scalers[symbol] = joblib.load(f"{path}_scaler.joblib")
        
        self.logger.info(f"Loaded model for {symbol} from {path}")


def generate_sample_data(symbols: List[str], days: int = 365) -> Dict[str, pd.DataFrame]:
    """
    Generate sample OHLCV data for testing.
    
    Args:
        symbols: List of symbols to generate data for
        days: Number of days of data to generate
        
    Returns:
        Dictionary mapping symbols to OHLCV DataFrames
    """
    data_dict = {}
    
    # Start date (1 year ago)
    end_date = datetime.datetime.now()
    start_date = end_date - datetime.timedelta(days=days)
    
    for symbol in symbols:
        # Generate timestamps
        timestamps = []
        current_date = start_date
        while current_date <= end_date:
            timestamps.append(current_date)
            current_date += datetime.timedelta(days=1)
        
        # Generate price data with random walk
        n = len(timestamps)
        
        # Different starting prices for different symbols
        if 'BTC' in symbol:
            start_price = 30000
        elif 'ETH' in symbol:
            start_price = 2000
        elif 'SOL' in symbol:
            start_price = 100
        elif 'BNB' in symbol:
            start_price = 300
        elif 'ADA' in symbol:
            start_price = 0.5
        elif 'XRP' in symbol:
            start_price = 0.6
        elif 'DOT' in symbol:
            start_price = 15
        elif 'DOGE' in symbol:
            start_price = 0.1
        elif 'AVAX' in symbol:
            start_price = 30
        else:
            start_price = 10
        
        close = [start_price]
        
        # Different trends for different symbols
        if 'BTC' in symbol or 'ETH' in symbol or 'SOL' in symbol:
            trend = 0.0008  # Bullish
        elif 'BNB' in symbol or 'ADA' in symbol or 'XRP' in symbol:
            trend = -0.0008  # Bearish
        else:
            trend = 0.0  # Neutral
        
        for i in range(1, n):
            # Random daily return between -3% and +3% with trend
            daily_return = np.random.normal(trend, 0.02)
            close.append(close[-1] * (1 + daily_return))
        
        # Generate OHLC based on close prices
        open_prices = [close[0]] + close[:-1]
        high = [c * (1 + abs(np.random.normal(0, 0.01))) for c in close]
        low = [c * (1 - abs(np.random.normal(0, 0.01))) for c in close]
        
        # Generate volume
        volume = [abs(np.random.normal(1000, 500)) * c for c in close]
        
        # Create DataFrame
        df = pd.DataFrame({
            'timestamp': timestamps,
            'open': open_prices,
            'high': high,
            'low': low,
            'close': close,
            'volume': volume
        })
        
        df.set_index('timestamp', inplace=True)
        data_dict[symbol] = df
    
    return data_dict


def run_sample_prediction():
    """
    Run a sample prediction for top 3 rising and falling coins.
    
    Returns:
        Dictionary with top predictions
    """
    # Set up logging
    logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    logger = logging.getLogger(__name__)
    
    # List of symbols
    symbols = [
        'BTC/USDT', 'ETH/USDT', 'SOL/USDT', 'BNB/USDT', 'ADA/USDT',
        'XRP/USDT', 'DOT/USDT', 'DOGE/USDT', 'AVAX/USDT', 'MATIC/USDT'
    ]
    
    # Generate sample data
    logger.info("Generating sample data...")
    data_dict = generate_sample_data(symbols, days=90)
    
    # Create prediction engine
    logger.info("Creating prediction engine...")
    engine = PredictionEngine(prediction_window=7, confidence_threshold=0.6)
    
    # Generate predictions
    logger.info("Generating predictions...")
    predictions = {}
    for symbol, df in data_dict.items():
        predictions[symbol] = engine.predict(symbol, df)
        logger.info(f"Prediction for {symbol}: {predictions[symbol].direction.value} with confidence {predictions[symbol].confidence:.4f}")
    
    # Get top predictions
    logger.info("Getting top predictions...")
    top_predictions = engine.get_top_predictions(predictions, top_n=3)
    
    # Print results
    logger.info("Top Bullish Predictions:")
    for pred in top_predictions['bullish']:
        logger.info(f"{pred.symbol}: Confidence {pred.confidence:.4f}")
    
    logger.info("Top Bearish Predictions:")
    for pred in top_predictions['bearish']:
        logger.info(f"{pred.symbol}: Confidence {pred.confidence:.4f}")
    
    # Create results directory
    os.makedirs("results", exist_ok=True)
    
    # Save predictions to file
    with open("results/predictions.txt", "w") as f:
        f.write("Top Bullish Predictions:\n")
        for pred in top_predictions['bullish']:
            f.write(f"{pred.symbol}: Confidence {pred.confidence:.4f}\n")
            f.write(f"  Key Indicators: RSI={pred.features.get('rsi_14', 'N/A'):.2f}, MACD={pred.features.get('macd', 'N/A'):.2f}\n")
        
        f.write("\nTop Bearish Predictions:\n")
        for pred in top_predictions['bearish']:
            f.write(f"{pred.symbol}: Confidence {pred.confidence:.4f}\n")
            f.write(f"  Key Indicators: RSI={pred.features.get('rsi_14', 'N/A'):.2f}, MACD={pred.features.get('macd', 'N/A'):.2f}\n")
    
    # Plot predictions
    plt.figure(figsize=(12, 8))
    
    # Prepare data for plotting
    symbols = []
    confidences = []
    colors = []
    
    for pred in top_predictions['bullish']:
        symbols.append(pred.symbol.replace('/USDT', ''))
        confidences.append(pred.confidence)
        colors.append('green')
    
    for pred in top_predictions['bearish']:
        symbols.append(pred.symbol.replace('/USDT', ''))
        confidences.append(pred.confidence)
        colors.append('red')
    
    # Create bar chart
    plt.bar(symbols, confidences, color=colors)
    plt.axhline(y=0.6, color='gray', linestyle='--', label='Confidence Threshold')
    
    plt.title('Top Cryptocurrency Predictions')
    plt.xlabel('Symbol')
    plt.ylabel('Confidence Score')
    plt.ylim(0, 1)
    plt.legend()
    plt.grid(axis='y', linestyle='--', alpha=0.7)
    
    # Save plot
    plt.savefig("results/predictions.png")
    
    return top_predictions


if __name__ == "__main__":
    top_predictions = run_sample_prediction()
    print("Prediction completed successfully!")
