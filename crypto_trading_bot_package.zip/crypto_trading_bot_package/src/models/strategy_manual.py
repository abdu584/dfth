"""
Strategy Module for Crypto Trading Bot (with manual indicator calculations).

This module implements various trading strategies:
- EMA Crossover
- RSI
- MACD
- Bollinger Bands
"""

import pandas as pd
import numpy as np
from typing import Dict, List, Optional, Union, Tuple, Any

# Update import to use absolute path
from src.models.data_structures import OHLCV, TimeFrame

class Strategy:
    """Base class for all trading strategies."""
    
    def __init__(self, name: str):
        """
        Initialize the strategy.
        
        Args:
            name: Name of the strategy
        """
        self.name = name
    
    def generate_signals(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Generate trading signals for the given data.
        
        Args:
            df: DataFrame with OHLCV data
            
        Returns:
            DataFrame with signals (1 for buy, -1 for sell, 0 for hold)
        """
        raise NotImplementedError("Subclasses must implement generate_signals")


class EMACrossoverStrategy(Strategy):
    """EMA Crossover strategy."""
    
    def __init__(self, fast_period: int = 12, slow_period: int = 26):
        """
        Initialize the EMA Crossover strategy.
        
        Args:
            fast_period: Period for the fast EMA
            slow_period: Period for the slow EMA
        """
        super().__init__("EMA Crossover")
        self.fast_period = fast_period
        self.slow_period = slow_period
    
    def generate_signals(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Generate trading signals based on EMA crossover.
        
        Args:
            df: DataFrame with OHLCV data
            
        Returns:
            DataFrame with signals
        """
        # Make a copy of the dataframe
        df = df.copy()
        
        # Calculate EMAs
        df['ema_fast'] = self._calculate_ema(df['close'], self.fast_period)
        df['ema_slow'] = self._calculate_ema(df['close'], self.slow_period)
        
        # Initialize signal column
        df['signal'] = 0
        
        # Generate signals
        for i in range(1, len(df)):
            # Buy signal: fast EMA crosses above slow EMA
            if df['ema_fast'].iloc[i-1] <= df['ema_slow'].iloc[i-1] and df['ema_fast'].iloc[i] > df['ema_slow'].iloc[i]:
                df['signal'].iloc[i] = 1
            
            # Sell signal: fast EMA crosses below slow EMA
            elif df['ema_fast'].iloc[i-1] >= df['ema_slow'].iloc[i-1] and df['ema_fast'].iloc[i] < df['ema_slow'].iloc[i]:
                df['signal'].iloc[i] = -1
        
        return df
    
    def _calculate_ema(self, series: pd.Series, period: int) -> pd.Series:
        """
        Calculate Exponential Moving Average.
        
        Args:
            series: Series of values
            period: EMA period
            
        Returns:
            Series with EMA values
        """
        # Calculate multiplier
        multiplier = 2 / (period + 1)
        
        # Calculate EMA
        ema = series.copy()
        ema.iloc[0:period] = series.iloc[0:period].mean()
        
        for i in range(period, len(series)):
            ema.iloc[i] = (series.iloc[i] * multiplier) + (ema.iloc[i-1] * (1 - multiplier))
        
        return ema


class RSIStrategy(Strategy):
    """RSI strategy."""
    
    def __init__(self, rsi_period: int = 14, overbought: float = 70, oversold: float = 30):
        """
        Initialize the RSI strategy.
        
        Args:
            rsi_period: Period for RSI calculation
            overbought: Overbought threshold
            oversold: Oversold threshold
        """
        super().__init__("RSI")
        self.rsi_period = rsi_period
        self.overbought = overbought
        self.oversold = oversold
    
    def generate_signals(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Generate trading signals based on RSI.
        
        Args:
            df: DataFrame with OHLCV data
            
        Returns:
            DataFrame with signals
        """
        # Make a copy of the dataframe
        df = df.copy()
        
        # Calculate RSI
        df['rsi'] = self._calculate_rsi(df['close'], self.rsi_period)
        
        # Initialize signal column
        df['signal'] = 0
        
        # Generate signals
        for i in range(1, len(df)):
            # Buy signal: RSI crosses above oversold threshold
            if df['rsi'].iloc[i-1] <= self.oversold and df['rsi'].iloc[i] > self.oversold:
                df['signal'].iloc[i] = 1
            
            # Sell signal: RSI crosses below overbought threshold
            elif df['rsi'].iloc[i-1] >= self.overbought and df['rsi'].iloc[i] < self.overbought:
                df['signal'].iloc[i] = -1
        
        return df
    
    def _calculate_rsi(self, series: pd.Series, period: int) -> pd.Series:
        """
        Calculate Relative Strength Index.
        
        Args:
            series: Series of values
            period: RSI period
            
        Returns:
            Series with RSI values
        """
        # Calculate price changes
        delta = series.diff()
        
        # Separate gains and losses
        gain = delta.copy()
        loss = delta.copy()
        gain[gain < 0] = 0
        loss[loss > 0] = 0
        loss = abs(loss)
        
        # Calculate average gain and loss
        avg_gain = gain.rolling(window=period).mean()
        avg_loss = loss.rolling(window=period).mean()
        
        # Calculate RS and RSI
        rs = avg_gain / avg_loss
        rsi = 100 - (100 / (1 + rs))
        
        return rsi


class MACDStrategy(Strategy):
    """MACD strategy."""
    
    def __init__(self, fast_period: int = 12, slow_period: int = 26, signal_period: int = 9):
        """
        Initialize the MACD strategy.
        
        Args:
            fast_period: Period for the fast EMA
            slow_period: Period for the slow EMA
            signal_period: Period for the signal line
        """
        super().__init__("MACD")
        self.fast_period = fast_period
        self.slow_period = slow_period
        self.signal_period = signal_period
    
    def generate_signals(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Generate trading signals based on MACD.
        
        Args:
            df: DataFrame with OHLCV data
            
        Returns:
            DataFrame with signals
        """
        # Make a copy of the dataframe
        df = df.copy()
        
        # Calculate MACD
        ema_fast = self._calculate_ema(df['close'], self.fast_period)
        ema_slow = self._calculate_ema(df['close'], self.slow_period)
        df['macd'] = ema_fast - ema_slow
        df['signal_line'] = self._calculate_ema(df['macd'], self.signal_period)
        df['histogram'] = df['macd'] - df['signal_line']
        
        # Initialize signal column
        df['signal'] = 0
        
        # Generate signals
        for i in range(1, len(df)):
            # Buy signal: MACD crosses above signal line
            if df['macd'].iloc[i-1] <= df['signal_line'].iloc[i-1] and df['macd'].iloc[i] > df['signal_line'].iloc[i]:
                df['signal'].iloc[i] = 1
            
            # Sell signal: MACD crosses below signal line
            elif df['macd'].iloc[i-1] >= df['signal_line'].iloc[i-1] and df['macd'].iloc[i] < df['signal_line'].iloc[i]:
                df['signal'].iloc[i] = -1
        
        return df
    
    def _calculate_ema(self, series: pd.Series, period: int) -> pd.Series:
        """
        Calculate Exponential Moving Average.
        
        Args:
            series: Series of values
            period: EMA period
            
        Returns:
            Series with EMA values
        """
        # Calculate multiplier
        multiplier = 2 / (period + 1)
        
        # Calculate EMA
        ema = series.copy()
        ema.iloc[0:period] = series.iloc[0:period].mean()
        
        for i in range(period, len(series)):
            ema.iloc[i] = (series.iloc[i] * multiplier) + (ema.iloc[i-1] * (1 - multiplier))
        
        return ema


class BollingerBandsStrategy(Strategy):
    """Bollinger Bands strategy."""
    
    def __init__(self, period: int = 20, std_dev: float = 2):
        """
        Initialize the Bollinger Bands strategy.
        
        Args:
            period: Period for the moving average
            std_dev: Number of standard deviations for the bands
        """
        super().__init__("Bollinger Bands")
        self.period = period
        self.std_dev = std_dev
    
    def generate_signals(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Generate trading signals based on Bollinger Bands.
        
        Args:
            df: DataFrame with OHLCV data
            
        Returns:
            DataFrame with signals
        """
        # Make a copy of the dataframe
        df = df.copy()
        
        # Calculate Bollinger Bands
        df['middle_band'] = df['close'].rolling(window=self.period).mean()
        df['std'] = df['close'].rolling(window=self.period).std()
        df['upper_band'] = df['middle_band'] + (df['std'] * self.std_dev)
        df['lower_band'] = df['middle_band'] - (df['std'] * self.std_dev)
        
        # Initialize signal column
        df['signal'] = 0
        
        # Generate signals
        for i in range(1, len(df)):
            # Buy signal: price crosses below lower band
            if df['close'].iloc[i-1] >= df['lower_band'].iloc[i-1] and df['close'].iloc[i] < df['lower_band'].iloc[i]:
                df['signal'].iloc[i] = 1
            
            # Sell signal: price crosses above upper band
            elif df['close'].iloc[i-1] <= df['upper_band'].iloc[i-1] and df['close'].iloc[i] > df['upper_band'].iloc[i]:
                df['signal'].iloc[i] = -1
        
        return df
