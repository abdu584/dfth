"""
Main entry point for the Flask application.
This file initializes the Flask app and registers all routes.
"""

import sys
import os
import json
import logging
from datetime import datetime, timedelta
from flask import Flask, render_template, request, jsonify, send_from_directory
import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from pathlib import Path

# Add the project root to the Python path
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

# Ensure the logs directory exists
os.makedirs(os.path.join(os.path.dirname(__file__), '..', 'logs'), exist_ok=True)
os.makedirs(os.path.join(os.path.dirname(__file__), '..', 'data'), exist_ok=True)
os.makedirs(os.path.join(os.path.dirname(__file__), 'static', 'img'), exist_ok=True)

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler(os.path.join(os.path.dirname(__file__), '..', 'logs', 'app.log'))
    ]
)
logger = logging.getLogger(__name__)

# Import bot modules - using local imports
from src.routes.api import api_bp
from src.routes.backtest import backtest_bp
from src.routes.prediction import prediction_bp
from src.routes.config import config_bp

# Create Flask app
app = Flask(__name__)

# Register blueprints
app.register_blueprint(api_bp, url_prefix='/api')
app.register_blueprint(backtest_bp, url_prefix='/api/backtest')
app.register_blueprint(prediction_bp, url_prefix='/api/predict')
app.register_blueprint(config_bp, url_prefix='/api/config')

# Uncomment the following line if you need to use mysql
# app.config['SQLALCHEMY_DATABASE_URI'] = f"mysql+pymysql://{os.getenv('DB_USERNAME', 'root')}:{os.getenv('DB_PASSWORD', 'password')}@{os.getenv('DB_HOST', 'localhost')}:{os.getenv('DB_PORT', '3306')}/{os.getenv('DB_NAME', 'mydb')}"

# Serve static files
@app.route('/')
def index():
    return send_from_directory('static', 'index.html')

@app.route('/static/<path:path>')
def serve_static(path):
    return send_from_directory('static', path)

# API routes for dashboard data
@app.route('/api/dashboard', methods=['GET'])
def get_dashboard_data():
    """
    Get dashboard data including equity curve, recent trades, and predictions.
    """
    try:
        # Load sample data or real data if available
        data = {
            'equity': generate_sample_equity_data(),
            'trades': generate_sample_trades(),
            'metrics': {
                'totalPnl': -57.82,
                'winRate': 0.1111,
                'sharpeRatio': -0.02,
                'maxDrawdown': 0.0251
            },
            'predictions': {
                'bullish': [],
                'bearish': [
                    {
                        'symbol': 'AVAX/USDT',
                        'confidence': 0.6974,
                        'indicators': 'RSI=37.73, MACD=-1.03'
                    },
                    {
                        'symbol': 'XRP/USDT',
                        'confidence': 0.6579,
                        'indicators': 'RSI=52.81, MACD=0.00'
                    },
                    {
                        'symbol': 'DOGE/USDT',
                        'confidence': 0.6579,
                        'indicators': 'RSI=57.52, MACD=-0.00'
                    }
                ]
            }
        }
        
        return jsonify(data)
    except Exception as e:
        logger.error(f"Error getting dashboard data: {str(e)}")
        return jsonify({'error': str(e)}), 500

def generate_sample_equity_data():
    """
    Generate sample equity curve data for demonstration.
    """
    data = []
    today = datetime.now()
    equity = 10000
    
    for i in range(30, -1, -1):
        date = today - timedelta(days=i)
        
        # Random daily return between -2% and +2%
        daily_return = (np.random.random() * 4 - 2) / 100
        equity = equity * (1 + daily_return)
        
        data.append({
            'date': date.strftime('%Y-%m-%d'),
            'value': equity
        })
    
    return data

def generate_sample_trades():
    """
    Generate sample trades data for demonstration.
    """
    symbols = ['BTC/USDT', 'ETH/USDT', 'SOL/USDT', 'BNB/USDT', 'ADA/USDT']
    trades = []
    
    for i in range(5):
        entry_price = np.random.uniform(100, 50000)
        exit_price = entry_price * (1 + np.random.uniform(-0.1, 0.1))
        pnl = exit_price - entry_price
        pnl_percentage = (pnl / entry_price) * 100
        
        trades.append({
            'symbol': np.random.choice(symbols),
            'side': 'BUY' if np.random.random() > 0.5 else 'SELL',
            'entryPrice': entry_price,
            'exitPrice': exit_price,
            'pnl': pnl,
            'pnlPercentage': pnl_percentage
        })
    
    return trades

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
