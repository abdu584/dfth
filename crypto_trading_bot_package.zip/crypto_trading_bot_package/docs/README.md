# Crypto Trading Bot Documentation

## Overview

This package contains a comprehensive crypto trading bot with a web interface. The bot is designed to:

1. Connect to multiple exchanges using APIs (Binance, Bybit, OKX)
2. Support both spot and futures trading operations
3. Perform backtests based on historical date ranges and initial capital
4. Generate predictions of rising (bullish) and falling (bearish) crypto assets
5. Output trade logs, performance summaries, and visual charts

## Project Structure

The project is organized into two main components:

### 1. Core Trading Bot (`/crypto_trading_bot`)

- `data_structures.py`: Core data classes for OHLCV data, orders, trades, etc.
- `api_connector.py`: Exchange API connectors for Binance, Bybit, and OKX
- `strategy_manual.py`: Trading strategies (EMA Crossover, RSI, MACD, Bollinger Bands)
- `backtest_manual.py`: Backtesting engine for simulating strategies on historical data
- `prediction_manual.py`: Prediction engine for identifying rising/falling assets
- `execution_engine.py`: Order execution for spot and futures markets
- `config_logging.py`: Configuration and logging utilities

### 2. Web Interface (`/src`)

- `main.py`: Flask application entry point
- `/routes`: API endpoints for backtesting, predictions, and configuration
- `/static`: Frontend assets (HTML, CSS, JavaScript)
- `/models`: Trading bot modules (copied from core bot)

## Setup Instructions

### Prerequisites

- Python 3.8+ installed
- pip package manager
- Internet connection for API access

### Installation

1. Clone or extract this package to your local machine
2. Create a virtual environment (recommended):
   ```
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```
3. Install dependencies:
   ```
   pip install -r requirements.txt
   ```

## Running the Bot

### Command Line Interface

To run the bot directly from the command line:

1. For backtesting:
   ```
   python backtest_manual.py
   ```

2. For predictions:
   ```
   python prediction_manual.py
   ```

Results will be saved in the `results` directory.

### Web Interface

To run the web interface:

1. Start the Flask server:
   ```
   cd src
   python main.py
   ```

2. Open your browser and navigate to:
   ```
   http://localhost:5000
   ```

3. Use the web interface to:
   - Configure API connections
   - Run backtests with different strategies
   - Generate predictions for crypto assets
   - View performance metrics and charts

## Features

### Backtesting Engine

- Test strategies on historical data
- Configure start date, end date, and initial capital
- Supports multiple timeframes (1m, 5m, 15m, 1h, 4h, 1d)
- Generates performance metrics (PnL, Sharpe ratio, win rate, etc.)
- Visualizes equity curve and trade history

### Prediction Engine

- Identifies bullish and bearish assets
- Uses technical indicators (RSI, MACD, Bollinger Bands)
- Provides confidence scores for predictions
- Visualizes prediction results

### Trading Strategies

1. **EMA Crossover**: Generates signals based on fast and slow EMA crossovers
2. **RSI**: Generates signals based on overbought/oversold conditions
3. **MACD**: Generates signals based on MACD line and signal line crossovers
4. **Bollinger Bands**: Generates signals based on price touching upper/lower bands

### API Connectors

- Supports Binance, Bybit, and OKX exchanges
- Handles authentication and API endpoints
- Retrieves market data and account information
- Places and manages orders

## Extending the Bot

### Adding New Strategies

1. Create a new strategy class in `strategy_manual.py` that inherits from the `Strategy` base class
2. Implement the `generate_signals` method to produce buy/sell signals
3. Register the strategy in the strategy factory methods

### Adding New Exchanges

1. Extend the `ExchangeConnector` class in `api_connector.py`
2. Implement exchange-specific API endpoints and authentication
3. Register the new exchange in the connector factory

### Customizing the Web Interface

1. Modify HTML templates in `src/static`
2. Update API routes in `src/routes`
3. Add new visualizations in the frontend JavaScript

## Troubleshooting

### Common Issues

1. **API Connection Errors**:
   - Verify API keys are correct
   - Check internet connection
   - Ensure exchange API is not under maintenance

2. **Backtesting Errors**:
   - Verify date range has sufficient data
   - Check strategy parameters are valid
   - Ensure initial capital is sufficient

3. **Web Interface Issues**:
   - Check Flask server is running
   - Verify port 5000 is not in use by another application
   - Clear browser cache if displaying outdated information

## License

This project is provided for educational and research purposes only. Use at your own risk.

## Disclaimer

Trading cryptocurrencies involves significant risk. This bot is provided as-is without any guarantees. Past performance is not indicative of future results. Always use proper risk management.
